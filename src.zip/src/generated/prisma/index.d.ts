
/**
 * Client
**/

import * as runtime from './runtime/client.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model User
 * 
 */
export type User = $Result.DefaultSelection<Prisma.$UserPayload>
/**
 * Model Workout
 * 
 */
export type Workout = $Result.DefaultSelection<Prisma.$WorkoutPayload>
/**
 * Model WorkoutPlan
 * 
 */
export type WorkoutPlan = $Result.DefaultSelection<Prisma.$WorkoutPlanPayload>
/**
 * Model PlanWorkout
 * 
 */
export type PlanWorkout = $Result.DefaultSelection<Prisma.$PlanWorkoutPayload>
/**
 * Model ProgressEntry
 * 
 */
export type ProgressEntry = $Result.DefaultSelection<Prisma.$ProgressEntryPayload>

/**
 * Enums
 */
export namespace $Enums {
  export const Role: {
  admin: 'admin',
  cadet: 'cadet'
};

export type Role = (typeof Role)[keyof typeof Role]

}

export type Role = $Enums.Role

export const Role: typeof $Enums.Role

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient({
 *   adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL })
 * })
 * // Fetch zero or more Users
 * const users = await prisma.user.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://pris.ly/d/client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  const U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient({
   *   adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL })
   * })
   * // Fetch zero or more Users
   * const users = await prisma.user.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://pris.ly/d/client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/orm/prisma-client/queries/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>

  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.user`: Exposes CRUD operations for the **User** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Users
    * const users = await prisma.user.findMany()
    * ```
    */
  get user(): Prisma.UserDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.workout`: Exposes CRUD operations for the **Workout** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Workouts
    * const workouts = await prisma.workout.findMany()
    * ```
    */
  get workout(): Prisma.WorkoutDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.workoutPlan`: Exposes CRUD operations for the **WorkoutPlan** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more WorkoutPlans
    * const workoutPlans = await prisma.workoutPlan.findMany()
    * ```
    */
  get workoutPlan(): Prisma.WorkoutPlanDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.planWorkout`: Exposes CRUD operations for the **PlanWorkout** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more PlanWorkouts
    * const planWorkouts = await prisma.planWorkout.findMany()
    * ```
    */
  get planWorkout(): Prisma.PlanWorkoutDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.progressEntry`: Exposes CRUD operations for the **ProgressEntry** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more ProgressEntries
    * const progressEntries = await prisma.progressEntry.findMany()
    * ```
    */
  get progressEntry(): Prisma.ProgressEntryDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 7.8.0
   * Query Engine version: 3c6e192761c0362d496ed980de936e2f3cebcd3a
   */
  export type PrismaVersion = {
    client: string
    engine: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import Bytes = runtime.Bytes
  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    User: 'User',
    Workout: 'Workout',
    WorkoutPlan: 'WorkoutPlan',
    PlanWorkout: 'PlanWorkout',
    ProgressEntry: 'ProgressEntry'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]



  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "user" | "workout" | "workoutPlan" | "planWorkout" | "progressEntry"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      User: {
        payload: Prisma.$UserPayload<ExtArgs>
        fields: Prisma.UserFieldRefs
        operations: {
          findUnique: {
            args: Prisma.UserFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.UserFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findFirst: {
            args: Prisma.UserFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.UserFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findMany: {
            args: Prisma.UserFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          create: {
            args: Prisma.UserCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          createMany: {
            args: Prisma.UserCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.UserCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          delete: {
            args: Prisma.UserDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          update: {
            args: Prisma.UserUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          deleteMany: {
            args: Prisma.UserDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.UserUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.UserUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          upsert: {
            args: Prisma.UserUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          aggregate: {
            args: Prisma.UserAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUser>
          }
          groupBy: {
            args: Prisma.UserGroupByArgs<ExtArgs>
            result: $Utils.Optional<UserGroupByOutputType>[]
          }
          count: {
            args: Prisma.UserCountArgs<ExtArgs>
            result: $Utils.Optional<UserCountAggregateOutputType> | number
          }
        }
      }
      Workout: {
        payload: Prisma.$WorkoutPayload<ExtArgs>
        fields: Prisma.WorkoutFieldRefs
        operations: {
          findUnique: {
            args: Prisma.WorkoutFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.WorkoutFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPayload>
          }
          findFirst: {
            args: Prisma.WorkoutFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.WorkoutFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPayload>
          }
          findMany: {
            args: Prisma.WorkoutFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPayload>[]
          }
          create: {
            args: Prisma.WorkoutCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPayload>
          }
          createMany: {
            args: Prisma.WorkoutCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.WorkoutCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPayload>[]
          }
          delete: {
            args: Prisma.WorkoutDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPayload>
          }
          update: {
            args: Prisma.WorkoutUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPayload>
          }
          deleteMany: {
            args: Prisma.WorkoutDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.WorkoutUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.WorkoutUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPayload>[]
          }
          upsert: {
            args: Prisma.WorkoutUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPayload>
          }
          aggregate: {
            args: Prisma.WorkoutAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateWorkout>
          }
          groupBy: {
            args: Prisma.WorkoutGroupByArgs<ExtArgs>
            result: $Utils.Optional<WorkoutGroupByOutputType>[]
          }
          count: {
            args: Prisma.WorkoutCountArgs<ExtArgs>
            result: $Utils.Optional<WorkoutCountAggregateOutputType> | number
          }
        }
      }
      WorkoutPlan: {
        payload: Prisma.$WorkoutPlanPayload<ExtArgs>
        fields: Prisma.WorkoutPlanFieldRefs
        operations: {
          findUnique: {
            args: Prisma.WorkoutPlanFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPlanPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.WorkoutPlanFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPlanPayload>
          }
          findFirst: {
            args: Prisma.WorkoutPlanFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPlanPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.WorkoutPlanFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPlanPayload>
          }
          findMany: {
            args: Prisma.WorkoutPlanFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPlanPayload>[]
          }
          create: {
            args: Prisma.WorkoutPlanCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPlanPayload>
          }
          createMany: {
            args: Prisma.WorkoutPlanCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.WorkoutPlanCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPlanPayload>[]
          }
          delete: {
            args: Prisma.WorkoutPlanDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPlanPayload>
          }
          update: {
            args: Prisma.WorkoutPlanUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPlanPayload>
          }
          deleteMany: {
            args: Prisma.WorkoutPlanDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.WorkoutPlanUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.WorkoutPlanUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPlanPayload>[]
          }
          upsert: {
            args: Prisma.WorkoutPlanUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPlanPayload>
          }
          aggregate: {
            args: Prisma.WorkoutPlanAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateWorkoutPlan>
          }
          groupBy: {
            args: Prisma.WorkoutPlanGroupByArgs<ExtArgs>
            result: $Utils.Optional<WorkoutPlanGroupByOutputType>[]
          }
          count: {
            args: Prisma.WorkoutPlanCountArgs<ExtArgs>
            result: $Utils.Optional<WorkoutPlanCountAggregateOutputType> | number
          }
        }
      }
      PlanWorkout: {
        payload: Prisma.$PlanWorkoutPayload<ExtArgs>
        fields: Prisma.PlanWorkoutFieldRefs
        operations: {
          findUnique: {
            args: Prisma.PlanWorkoutFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlanWorkoutPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.PlanWorkoutFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlanWorkoutPayload>
          }
          findFirst: {
            args: Prisma.PlanWorkoutFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlanWorkoutPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.PlanWorkoutFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlanWorkoutPayload>
          }
          findMany: {
            args: Prisma.PlanWorkoutFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlanWorkoutPayload>[]
          }
          create: {
            args: Prisma.PlanWorkoutCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlanWorkoutPayload>
          }
          createMany: {
            args: Prisma.PlanWorkoutCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.PlanWorkoutCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlanWorkoutPayload>[]
          }
          delete: {
            args: Prisma.PlanWorkoutDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlanWorkoutPayload>
          }
          update: {
            args: Prisma.PlanWorkoutUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlanWorkoutPayload>
          }
          deleteMany: {
            args: Prisma.PlanWorkoutDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.PlanWorkoutUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.PlanWorkoutUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlanWorkoutPayload>[]
          }
          upsert: {
            args: Prisma.PlanWorkoutUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlanWorkoutPayload>
          }
          aggregate: {
            args: Prisma.PlanWorkoutAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregatePlanWorkout>
          }
          groupBy: {
            args: Prisma.PlanWorkoutGroupByArgs<ExtArgs>
            result: $Utils.Optional<PlanWorkoutGroupByOutputType>[]
          }
          count: {
            args: Prisma.PlanWorkoutCountArgs<ExtArgs>
            result: $Utils.Optional<PlanWorkoutCountAggregateOutputType> | number
          }
        }
      }
      ProgressEntry: {
        payload: Prisma.$ProgressEntryPayload<ExtArgs>
        fields: Prisma.ProgressEntryFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ProgressEntryFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProgressEntryPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ProgressEntryFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProgressEntryPayload>
          }
          findFirst: {
            args: Prisma.ProgressEntryFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProgressEntryPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ProgressEntryFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProgressEntryPayload>
          }
          findMany: {
            args: Prisma.ProgressEntryFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProgressEntryPayload>[]
          }
          create: {
            args: Prisma.ProgressEntryCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProgressEntryPayload>
          }
          createMany: {
            args: Prisma.ProgressEntryCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.ProgressEntryCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProgressEntryPayload>[]
          }
          delete: {
            args: Prisma.ProgressEntryDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProgressEntryPayload>
          }
          update: {
            args: Prisma.ProgressEntryUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProgressEntryPayload>
          }
          deleteMany: {
            args: Prisma.ProgressEntryDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ProgressEntryUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.ProgressEntryUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProgressEntryPayload>[]
          }
          upsert: {
            args: Prisma.ProgressEntryUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProgressEntryPayload>
          }
          aggregate: {
            args: Prisma.ProgressEntryAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateProgressEntry>
          }
          groupBy: {
            args: Prisma.ProgressEntryGroupByArgs<ExtArgs>
            result: $Utils.Optional<ProgressEntryGroupByOutputType>[]
          }
          count: {
            args: Prisma.ProgressEntryCountArgs<ExtArgs>
            result: $Utils.Optional<ProgressEntryCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Shorthand for `emit: 'stdout'`
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events only
     * log: [
     *   { emit: 'event', level: 'query' },
     *   { emit: 'event', level: 'info' },
     *   { emit: 'event', level: 'warn' }
     *   { emit: 'event', level: 'error' }
     * ]
     * 
     * / Emit as events and log to stdout
     * og: [
     *  { emit: 'stdout', level: 'query' },
     *  { emit: 'stdout', level: 'info' },
     *  { emit: 'stdout', level: 'warn' }
     *  { emit: 'stdout', level: 'error' }
     * 
     * ```
     * Read more in our [docs](https://pris.ly/d/logging).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Instance of a Driver Adapter, e.g., like one provided by `@prisma/adapter-planetscale`
     */
    adapter?: runtime.SqlDriverAdapterFactory
    /**
     * Prisma Accelerate URL allowing the client to connect through Accelerate instead of a direct database.
     */
    accelerateUrl?: string
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
    /**
     * SQL commenter plugins that add metadata to SQL queries as comments.
     * Comments follow the sqlcommenter format: https://google.github.io/sqlcommenter/
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   adapter,
     *   comments: [
     *     traceContext(),
     *     queryInsights(),
     *   ],
     * })
     * ```
     */
    comments?: runtime.SqlCommenterPlugin[]
  }
  export type GlobalOmitConfig = {
    user?: UserOmit
    workout?: WorkoutOmit
    workoutPlan?: WorkoutPlanOmit
    planWorkout?: PlanWorkoutOmit
    progressEntry?: ProgressEntryOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type CheckIsLogLevel<T> = T extends LogLevel ? T : never;

  export type GetLogType<T> = CheckIsLogLevel<
    T extends LogDefinition ? T['level'] : T
  >;

  export type GetEvents<T extends any[]> = T extends Array<LogLevel | LogDefinition>
    ? GetLogType<T[number]>
    : never;

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type UserCountOutputType
   */

  export type UserCountOutputType = {
    workoutPlans: number
    progressEntries: number
  }

  export type UserCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    workoutPlans?: boolean | UserCountOutputTypeCountWorkoutPlansArgs
    progressEntries?: boolean | UserCountOutputTypeCountProgressEntriesArgs
  }

  // Custom InputTypes
  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserCountOutputType
     */
    select?: UserCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountWorkoutPlansArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: WorkoutPlanWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountProgressEntriesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ProgressEntryWhereInput
  }


  /**
   * Count Type WorkoutCountOutputType
   */

  export type WorkoutCountOutputType = {
    planWorkouts: number
    progressEntries: number
  }

  export type WorkoutCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    planWorkouts?: boolean | WorkoutCountOutputTypeCountPlanWorkoutsArgs
    progressEntries?: boolean | WorkoutCountOutputTypeCountProgressEntriesArgs
  }

  // Custom InputTypes
  /**
   * WorkoutCountOutputType without action
   */
  export type WorkoutCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutCountOutputType
     */
    select?: WorkoutCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * WorkoutCountOutputType without action
   */
  export type WorkoutCountOutputTypeCountPlanWorkoutsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PlanWorkoutWhereInput
  }

  /**
   * WorkoutCountOutputType without action
   */
  export type WorkoutCountOutputTypeCountProgressEntriesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ProgressEntryWhereInput
  }


  /**
   * Count Type WorkoutPlanCountOutputType
   */

  export type WorkoutPlanCountOutputType = {
    planWorkouts: number
  }

  export type WorkoutPlanCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    planWorkouts?: boolean | WorkoutPlanCountOutputTypeCountPlanWorkoutsArgs
  }

  // Custom InputTypes
  /**
   * WorkoutPlanCountOutputType without action
   */
  export type WorkoutPlanCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlanCountOutputType
     */
    select?: WorkoutPlanCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * WorkoutPlanCountOutputType without action
   */
  export type WorkoutPlanCountOutputTypeCountPlanWorkoutsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PlanWorkoutWhereInput
  }


  /**
   * Models
   */

  /**
   * Model User
   */

  export type AggregateUser = {
    _count: UserCountAggregateOutputType | null
    _avg: UserAvgAggregateOutputType | null
    _sum: UserSumAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  export type UserAvgAggregateOutputType = {
    id: number | null
  }

  export type UserSumAggregateOutputType = {
    id: number | null
  }

  export type UserMinAggregateOutputType = {
    id: number | null
    name: string | null
    email: string | null
    password_hash: string | null
    role: $Enums.Role | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type UserMaxAggregateOutputType = {
    id: number | null
    name: string | null
    email: string | null
    password_hash: string | null
    role: $Enums.Role | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type UserCountAggregateOutputType = {
    id: number
    name: number
    email: number
    password_hash: number
    role: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type UserAvgAggregateInputType = {
    id?: true
  }

  export type UserSumAggregateInputType = {
    id?: true
  }

  export type UserMinAggregateInputType = {
    id?: true
    name?: true
    email?: true
    password_hash?: true
    role?: true
    createdAt?: true
    updatedAt?: true
  }

  export type UserMaxAggregateInputType = {
    id?: true
    name?: true
    email?: true
    password_hash?: true
    role?: true
    createdAt?: true
    updatedAt?: true
  }

  export type UserCountAggregateInputType = {
    id?: true
    name?: true
    email?: true
    password_hash?: true
    role?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type UserAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which User to aggregate.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Users
    **/
    _count?: true | UserCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: UserAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: UserSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UserMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UserMaxAggregateInputType
  }

  export type GetUserAggregateType<T extends UserAggregateArgs> = {
        [P in keyof T & keyof AggregateUser]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUser[P]>
      : GetScalarType<T[P], AggregateUser[P]>
  }




  export type UserGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserWhereInput
    orderBy?: UserOrderByWithAggregationInput | UserOrderByWithAggregationInput[]
    by: UserScalarFieldEnum[] | UserScalarFieldEnum
    having?: UserScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UserCountAggregateInputType | true
    _avg?: UserAvgAggregateInputType
    _sum?: UserSumAggregateInputType
    _min?: UserMinAggregateInputType
    _max?: UserMaxAggregateInputType
  }

  export type UserGroupByOutputType = {
    id: number
    name: string
    email: string
    password_hash: string
    role: $Enums.Role
    createdAt: Date
    updatedAt: Date
    _count: UserCountAggregateOutputType | null
    _avg: UserAvgAggregateOutputType | null
    _sum: UserSumAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  type GetUserGroupByPayload<T extends UserGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UserGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UserGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UserGroupByOutputType[P]>
            : GetScalarType<T[P], UserGroupByOutputType[P]>
        }
      >
    >


  export type UserSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    email?: boolean
    password_hash?: boolean
    role?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    workoutPlans?: boolean | User$workoutPlansArgs<ExtArgs>
    progressEntries?: boolean | User$progressEntriesArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["user"]>

  export type UserSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    email?: boolean
    password_hash?: boolean
    role?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["user"]>

  export type UserSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    email?: boolean
    password_hash?: boolean
    role?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["user"]>

  export type UserSelectScalar = {
    id?: boolean
    name?: boolean
    email?: boolean
    password_hash?: boolean
    role?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type UserOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "email" | "password_hash" | "role" | "createdAt" | "updatedAt", ExtArgs["result"]["user"]>
  export type UserInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    workoutPlans?: boolean | User$workoutPlansArgs<ExtArgs>
    progressEntries?: boolean | User$progressEntriesArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type UserIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type UserIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $UserPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "User"
    objects: {
      workoutPlans: Prisma.$WorkoutPlanPayload<ExtArgs>[]
      progressEntries: Prisma.$ProgressEntryPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      name: string
      email: string
      password_hash: string
      role: $Enums.Role
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["user"]>
    composites: {}
  }

  type UserGetPayload<S extends boolean | null | undefined | UserDefaultArgs> = $Result.GetResult<Prisma.$UserPayload, S>

  type UserCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<UserFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: UserCountAggregateInputType | true
    }

  export interface UserDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['User'], meta: { name: 'User' } }
    /**
     * Find zero or one User that matches the filter.
     * @param {UserFindUniqueArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends UserFindUniqueArgs>(args: SelectSubset<T, UserFindUniqueArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one User that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {UserFindUniqueOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends UserFindUniqueOrThrowArgs>(args: SelectSubset<T, UserFindUniqueOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends UserFindFirstArgs>(args?: SelectSubset<T, UserFindFirstArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends UserFindFirstOrThrowArgs>(args?: SelectSubset<T, UserFindFirstOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Users that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Users
     * const users = await prisma.user.findMany()
     * 
     * // Get first 10 Users
     * const users = await prisma.user.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const userWithIdOnly = await prisma.user.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends UserFindManyArgs>(args?: SelectSubset<T, UserFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a User.
     * @param {UserCreateArgs} args - Arguments to create a User.
     * @example
     * // Create one User
     * const User = await prisma.user.create({
     *   data: {
     *     // ... data to create a User
     *   }
     * })
     * 
     */
    create<T extends UserCreateArgs>(args: SelectSubset<T, UserCreateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Users.
     * @param {UserCreateManyArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const user = await prisma.user.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends UserCreateManyArgs>(args?: SelectSubset<T, UserCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Users and returns the data saved in the database.
     * @param {UserCreateManyAndReturnArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const user = await prisma.user.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Users and only return the `id`
     * const userWithIdOnly = await prisma.user.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends UserCreateManyAndReturnArgs>(args?: SelectSubset<T, UserCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a User.
     * @param {UserDeleteArgs} args - Arguments to delete one User.
     * @example
     * // Delete one User
     * const User = await prisma.user.delete({
     *   where: {
     *     // ... filter to delete one User
     *   }
     * })
     * 
     */
    delete<T extends UserDeleteArgs>(args: SelectSubset<T, UserDeleteArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one User.
     * @param {UserUpdateArgs} args - Arguments to update one User.
     * @example
     * // Update one User
     * const user = await prisma.user.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends UserUpdateArgs>(args: SelectSubset<T, UserUpdateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Users.
     * @param {UserDeleteManyArgs} args - Arguments to filter Users to delete.
     * @example
     * // Delete a few Users
     * const { count } = await prisma.user.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends UserDeleteManyArgs>(args?: SelectSubset<T, UserDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Users
     * const user = await prisma.user.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends UserUpdateManyArgs>(args: SelectSubset<T, UserUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users and returns the data updated in the database.
     * @param {UserUpdateManyAndReturnArgs} args - Arguments to update many Users.
     * @example
     * // Update many Users
     * const user = await prisma.user.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Users and only return the `id`
     * const userWithIdOnly = await prisma.user.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends UserUpdateManyAndReturnArgs>(args: SelectSubset<T, UserUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one User.
     * @param {UserUpsertArgs} args - Arguments to update or create a User.
     * @example
     * // Update or create a User
     * const user = await prisma.user.upsert({
     *   create: {
     *     // ... data to create a User
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the User we want to update
     *   }
     * })
     */
    upsert<T extends UserUpsertArgs>(args: SelectSubset<T, UserUpsertArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserCountArgs} args - Arguments to filter Users to count.
     * @example
     * // Count the number of Users
     * const count = await prisma.user.count({
     *   where: {
     *     // ... the filter for the Users we want to count
     *   }
     * })
    **/
    count<T extends UserCountArgs>(
      args?: Subset<T, UserCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UserCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UserAggregateArgs>(args: Subset<T, UserAggregateArgs>): Prisma.PrismaPromise<GetUserAggregateType<T>>

    /**
     * Group by User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends UserGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: UserGroupByArgs['orderBy'] }
        : { orderBy?: UserGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, UserGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUserGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the User model
   */
  readonly fields: UserFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for User.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__UserClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    workoutPlans<T extends User$workoutPlansArgs<ExtArgs> = {}>(args?: Subset<T, User$workoutPlansArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    progressEntries<T extends User$progressEntriesArgs<ExtArgs> = {}>(args?: Subset<T, User$progressEntriesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ProgressEntryPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the User model
   */
  interface UserFieldRefs {
    readonly id: FieldRef<"User", 'Int'>
    readonly name: FieldRef<"User", 'String'>
    readonly email: FieldRef<"User", 'String'>
    readonly password_hash: FieldRef<"User", 'String'>
    readonly role: FieldRef<"User", 'Role'>
    readonly createdAt: FieldRef<"User", 'DateTime'>
    readonly updatedAt: FieldRef<"User", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * User findUnique
   */
  export type UserFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findUniqueOrThrow
   */
  export type UserFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findFirst
   */
  export type UserFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findFirstOrThrow
   */
  export type UserFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findMany
   */
  export type UserFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which Users to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User create
   */
  export type UserCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to create a User.
     */
    data: XOR<UserCreateInput, UserUncheckedCreateInput>
  }

  /**
   * User createMany
   */
  export type UserCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Users.
     */
    data: UserCreateManyInput | UserCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * User createManyAndReturn
   */
  export type UserCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * The data used to create many Users.
     */
    data: UserCreateManyInput | UserCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * User update
   */
  export type UserUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to update a User.
     */
    data: XOR<UserUpdateInput, UserUncheckedUpdateInput>
    /**
     * Choose, which User to update.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User updateMany
   */
  export type UserUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Users.
     */
    data: XOR<UserUpdateManyMutationInput, UserUncheckedUpdateManyInput>
    /**
     * Filter which Users to update
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to update.
     */
    limit?: number
  }

  /**
   * User updateManyAndReturn
   */
  export type UserUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * The data used to update Users.
     */
    data: XOR<UserUpdateManyMutationInput, UserUncheckedUpdateManyInput>
    /**
     * Filter which Users to update
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to update.
     */
    limit?: number
  }

  /**
   * User upsert
   */
  export type UserUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The filter to search for the User to update in case it exists.
     */
    where: UserWhereUniqueInput
    /**
     * In case the User found by the `where` argument doesn't exist, create a new User with this data.
     */
    create: XOR<UserCreateInput, UserUncheckedCreateInput>
    /**
     * In case the User was found with the provided `where` argument, update it with this data.
     */
    update: XOR<UserUpdateInput, UserUncheckedUpdateInput>
  }

  /**
   * User delete
   */
  export type UserDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter which User to delete.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User deleteMany
   */
  export type UserDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Users to delete
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to delete.
     */
    limit?: number
  }

  /**
   * User.workoutPlans
   */
  export type User$workoutPlansArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanInclude<ExtArgs> | null
    where?: WorkoutPlanWhereInput
    orderBy?: WorkoutPlanOrderByWithRelationInput | WorkoutPlanOrderByWithRelationInput[]
    cursor?: WorkoutPlanWhereUniqueInput
    take?: number
    skip?: number
    distinct?: WorkoutPlanScalarFieldEnum | WorkoutPlanScalarFieldEnum[]
  }

  /**
   * User.progressEntries
   */
  export type User$progressEntriesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProgressEntry
     */
    select?: ProgressEntrySelect<ExtArgs> | null
    /**
     * Omit specific fields from the ProgressEntry
     */
    omit?: ProgressEntryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProgressEntryInclude<ExtArgs> | null
    where?: ProgressEntryWhereInput
    orderBy?: ProgressEntryOrderByWithRelationInput | ProgressEntryOrderByWithRelationInput[]
    cursor?: ProgressEntryWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ProgressEntryScalarFieldEnum | ProgressEntryScalarFieldEnum[]
  }

  /**
   * User without action
   */
  export type UserDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
  }


  /**
   * Model Workout
   */

  export type AggregateWorkout = {
    _count: WorkoutCountAggregateOutputType | null
    _avg: WorkoutAvgAggregateOutputType | null
    _sum: WorkoutSumAggregateOutputType | null
    _min: WorkoutMinAggregateOutputType | null
    _max: WorkoutMaxAggregateOutputType | null
  }

  export type WorkoutAvgAggregateOutputType = {
    id: number | null
    duration_minutes: number | null
  }

  export type WorkoutSumAggregateOutputType = {
    id: number | null
    duration_minutes: number | null
  }

  export type WorkoutMinAggregateOutputType = {
    id: number | null
    title: string | null
    description: string | null
    category: string | null
    difficulty: string | null
    duration_minutes: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type WorkoutMaxAggregateOutputType = {
    id: number | null
    title: string | null
    description: string | null
    category: string | null
    difficulty: string | null
    duration_minutes: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type WorkoutCountAggregateOutputType = {
    id: number
    title: number
    description: number
    category: number
    difficulty: number
    duration_minutes: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type WorkoutAvgAggregateInputType = {
    id?: true
    duration_minutes?: true
  }

  export type WorkoutSumAggregateInputType = {
    id?: true
    duration_minutes?: true
  }

  export type WorkoutMinAggregateInputType = {
    id?: true
    title?: true
    description?: true
    category?: true
    difficulty?: true
    duration_minutes?: true
    createdAt?: true
    updatedAt?: true
  }

  export type WorkoutMaxAggregateInputType = {
    id?: true
    title?: true
    description?: true
    category?: true
    difficulty?: true
    duration_minutes?: true
    createdAt?: true
    updatedAt?: true
  }

  export type WorkoutCountAggregateInputType = {
    id?: true
    title?: true
    description?: true
    category?: true
    difficulty?: true
    duration_minutes?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type WorkoutAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Workout to aggregate.
     */
    where?: WorkoutWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Workouts to fetch.
     */
    orderBy?: WorkoutOrderByWithRelationInput | WorkoutOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: WorkoutWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Workouts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Workouts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Workouts
    **/
    _count?: true | WorkoutCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: WorkoutAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: WorkoutSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: WorkoutMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: WorkoutMaxAggregateInputType
  }

  export type GetWorkoutAggregateType<T extends WorkoutAggregateArgs> = {
        [P in keyof T & keyof AggregateWorkout]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateWorkout[P]>
      : GetScalarType<T[P], AggregateWorkout[P]>
  }




  export type WorkoutGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: WorkoutWhereInput
    orderBy?: WorkoutOrderByWithAggregationInput | WorkoutOrderByWithAggregationInput[]
    by: WorkoutScalarFieldEnum[] | WorkoutScalarFieldEnum
    having?: WorkoutScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: WorkoutCountAggregateInputType | true
    _avg?: WorkoutAvgAggregateInputType
    _sum?: WorkoutSumAggregateInputType
    _min?: WorkoutMinAggregateInputType
    _max?: WorkoutMaxAggregateInputType
  }

  export type WorkoutGroupByOutputType = {
    id: number
    title: string
    description: string
    category: string
    difficulty: string
    duration_minutes: number
    createdAt: Date
    updatedAt: Date
    _count: WorkoutCountAggregateOutputType | null
    _avg: WorkoutAvgAggregateOutputType | null
    _sum: WorkoutSumAggregateOutputType | null
    _min: WorkoutMinAggregateOutputType | null
    _max: WorkoutMaxAggregateOutputType | null
  }

  type GetWorkoutGroupByPayload<T extends WorkoutGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<WorkoutGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof WorkoutGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], WorkoutGroupByOutputType[P]>
            : GetScalarType<T[P], WorkoutGroupByOutputType[P]>
        }
      >
    >


  export type WorkoutSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    title?: boolean
    description?: boolean
    category?: boolean
    difficulty?: boolean
    duration_minutes?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    planWorkouts?: boolean | Workout$planWorkoutsArgs<ExtArgs>
    progressEntries?: boolean | Workout$progressEntriesArgs<ExtArgs>
    _count?: boolean | WorkoutCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["workout"]>

  export type WorkoutSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    title?: boolean
    description?: boolean
    category?: boolean
    difficulty?: boolean
    duration_minutes?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["workout"]>

  export type WorkoutSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    title?: boolean
    description?: boolean
    category?: boolean
    difficulty?: boolean
    duration_minutes?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["workout"]>

  export type WorkoutSelectScalar = {
    id?: boolean
    title?: boolean
    description?: boolean
    category?: boolean
    difficulty?: boolean
    duration_minutes?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type WorkoutOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "title" | "description" | "category" | "difficulty" | "duration_minutes" | "createdAt" | "updatedAt", ExtArgs["result"]["workout"]>
  export type WorkoutInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    planWorkouts?: boolean | Workout$planWorkoutsArgs<ExtArgs>
    progressEntries?: boolean | Workout$progressEntriesArgs<ExtArgs>
    _count?: boolean | WorkoutCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type WorkoutIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type WorkoutIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $WorkoutPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Workout"
    objects: {
      planWorkouts: Prisma.$PlanWorkoutPayload<ExtArgs>[]
      progressEntries: Prisma.$ProgressEntryPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      title: string
      description: string
      category: string
      difficulty: string
      duration_minutes: number
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["workout"]>
    composites: {}
  }

  type WorkoutGetPayload<S extends boolean | null | undefined | WorkoutDefaultArgs> = $Result.GetResult<Prisma.$WorkoutPayload, S>

  type WorkoutCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<WorkoutFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: WorkoutCountAggregateInputType | true
    }

  export interface WorkoutDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Workout'], meta: { name: 'Workout' } }
    /**
     * Find zero or one Workout that matches the filter.
     * @param {WorkoutFindUniqueArgs} args - Arguments to find a Workout
     * @example
     * // Get one Workout
     * const workout = await prisma.workout.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends WorkoutFindUniqueArgs>(args: SelectSubset<T, WorkoutFindUniqueArgs<ExtArgs>>): Prisma__WorkoutClient<$Result.GetResult<Prisma.$WorkoutPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Workout that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {WorkoutFindUniqueOrThrowArgs} args - Arguments to find a Workout
     * @example
     * // Get one Workout
     * const workout = await prisma.workout.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends WorkoutFindUniqueOrThrowArgs>(args: SelectSubset<T, WorkoutFindUniqueOrThrowArgs<ExtArgs>>): Prisma__WorkoutClient<$Result.GetResult<Prisma.$WorkoutPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Workout that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutFindFirstArgs} args - Arguments to find a Workout
     * @example
     * // Get one Workout
     * const workout = await prisma.workout.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends WorkoutFindFirstArgs>(args?: SelectSubset<T, WorkoutFindFirstArgs<ExtArgs>>): Prisma__WorkoutClient<$Result.GetResult<Prisma.$WorkoutPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Workout that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutFindFirstOrThrowArgs} args - Arguments to find a Workout
     * @example
     * // Get one Workout
     * const workout = await prisma.workout.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends WorkoutFindFirstOrThrowArgs>(args?: SelectSubset<T, WorkoutFindFirstOrThrowArgs<ExtArgs>>): Prisma__WorkoutClient<$Result.GetResult<Prisma.$WorkoutPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Workouts that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Workouts
     * const workouts = await prisma.workout.findMany()
     * 
     * // Get first 10 Workouts
     * const workouts = await prisma.workout.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const workoutWithIdOnly = await prisma.workout.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends WorkoutFindManyArgs>(args?: SelectSubset<T, WorkoutFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WorkoutPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Workout.
     * @param {WorkoutCreateArgs} args - Arguments to create a Workout.
     * @example
     * // Create one Workout
     * const Workout = await prisma.workout.create({
     *   data: {
     *     // ... data to create a Workout
     *   }
     * })
     * 
     */
    create<T extends WorkoutCreateArgs>(args: SelectSubset<T, WorkoutCreateArgs<ExtArgs>>): Prisma__WorkoutClient<$Result.GetResult<Prisma.$WorkoutPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Workouts.
     * @param {WorkoutCreateManyArgs} args - Arguments to create many Workouts.
     * @example
     * // Create many Workouts
     * const workout = await prisma.workout.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends WorkoutCreateManyArgs>(args?: SelectSubset<T, WorkoutCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Workouts and returns the data saved in the database.
     * @param {WorkoutCreateManyAndReturnArgs} args - Arguments to create many Workouts.
     * @example
     * // Create many Workouts
     * const workout = await prisma.workout.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Workouts and only return the `id`
     * const workoutWithIdOnly = await prisma.workout.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends WorkoutCreateManyAndReturnArgs>(args?: SelectSubset<T, WorkoutCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WorkoutPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Workout.
     * @param {WorkoutDeleteArgs} args - Arguments to delete one Workout.
     * @example
     * // Delete one Workout
     * const Workout = await prisma.workout.delete({
     *   where: {
     *     // ... filter to delete one Workout
     *   }
     * })
     * 
     */
    delete<T extends WorkoutDeleteArgs>(args: SelectSubset<T, WorkoutDeleteArgs<ExtArgs>>): Prisma__WorkoutClient<$Result.GetResult<Prisma.$WorkoutPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Workout.
     * @param {WorkoutUpdateArgs} args - Arguments to update one Workout.
     * @example
     * // Update one Workout
     * const workout = await prisma.workout.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends WorkoutUpdateArgs>(args: SelectSubset<T, WorkoutUpdateArgs<ExtArgs>>): Prisma__WorkoutClient<$Result.GetResult<Prisma.$WorkoutPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Workouts.
     * @param {WorkoutDeleteManyArgs} args - Arguments to filter Workouts to delete.
     * @example
     * // Delete a few Workouts
     * const { count } = await prisma.workout.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends WorkoutDeleteManyArgs>(args?: SelectSubset<T, WorkoutDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Workouts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Workouts
     * const workout = await prisma.workout.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends WorkoutUpdateManyArgs>(args: SelectSubset<T, WorkoutUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Workouts and returns the data updated in the database.
     * @param {WorkoutUpdateManyAndReturnArgs} args - Arguments to update many Workouts.
     * @example
     * // Update many Workouts
     * const workout = await prisma.workout.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Workouts and only return the `id`
     * const workoutWithIdOnly = await prisma.workout.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends WorkoutUpdateManyAndReturnArgs>(args: SelectSubset<T, WorkoutUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WorkoutPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Workout.
     * @param {WorkoutUpsertArgs} args - Arguments to update or create a Workout.
     * @example
     * // Update or create a Workout
     * const workout = await prisma.workout.upsert({
     *   create: {
     *     // ... data to create a Workout
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Workout we want to update
     *   }
     * })
     */
    upsert<T extends WorkoutUpsertArgs>(args: SelectSubset<T, WorkoutUpsertArgs<ExtArgs>>): Prisma__WorkoutClient<$Result.GetResult<Prisma.$WorkoutPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Workouts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutCountArgs} args - Arguments to filter Workouts to count.
     * @example
     * // Count the number of Workouts
     * const count = await prisma.workout.count({
     *   where: {
     *     // ... the filter for the Workouts we want to count
     *   }
     * })
    **/
    count<T extends WorkoutCountArgs>(
      args?: Subset<T, WorkoutCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], WorkoutCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Workout.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends WorkoutAggregateArgs>(args: Subset<T, WorkoutAggregateArgs>): Prisma.PrismaPromise<GetWorkoutAggregateType<T>>

    /**
     * Group by Workout.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends WorkoutGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: WorkoutGroupByArgs['orderBy'] }
        : { orderBy?: WorkoutGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, WorkoutGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetWorkoutGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Workout model
   */
  readonly fields: WorkoutFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Workout.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__WorkoutClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    planWorkouts<T extends Workout$planWorkoutsArgs<ExtArgs> = {}>(args?: Subset<T, Workout$planWorkoutsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PlanWorkoutPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    progressEntries<T extends Workout$progressEntriesArgs<ExtArgs> = {}>(args?: Subset<T, Workout$progressEntriesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ProgressEntryPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Workout model
   */
  interface WorkoutFieldRefs {
    readonly id: FieldRef<"Workout", 'Int'>
    readonly title: FieldRef<"Workout", 'String'>
    readonly description: FieldRef<"Workout", 'String'>
    readonly category: FieldRef<"Workout", 'String'>
    readonly difficulty: FieldRef<"Workout", 'String'>
    readonly duration_minutes: FieldRef<"Workout", 'Int'>
    readonly createdAt: FieldRef<"Workout", 'DateTime'>
    readonly updatedAt: FieldRef<"Workout", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Workout findUnique
   */
  export type WorkoutFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Workout
     */
    select?: WorkoutSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Workout
     */
    omit?: WorkoutOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutInclude<ExtArgs> | null
    /**
     * Filter, which Workout to fetch.
     */
    where: WorkoutWhereUniqueInput
  }

  /**
   * Workout findUniqueOrThrow
   */
  export type WorkoutFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Workout
     */
    select?: WorkoutSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Workout
     */
    omit?: WorkoutOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutInclude<ExtArgs> | null
    /**
     * Filter, which Workout to fetch.
     */
    where: WorkoutWhereUniqueInput
  }

  /**
   * Workout findFirst
   */
  export type WorkoutFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Workout
     */
    select?: WorkoutSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Workout
     */
    omit?: WorkoutOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutInclude<ExtArgs> | null
    /**
     * Filter, which Workout to fetch.
     */
    where?: WorkoutWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Workouts to fetch.
     */
    orderBy?: WorkoutOrderByWithRelationInput | WorkoutOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Workouts.
     */
    cursor?: WorkoutWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Workouts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Workouts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Workouts.
     */
    distinct?: WorkoutScalarFieldEnum | WorkoutScalarFieldEnum[]
  }

  /**
   * Workout findFirstOrThrow
   */
  export type WorkoutFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Workout
     */
    select?: WorkoutSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Workout
     */
    omit?: WorkoutOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutInclude<ExtArgs> | null
    /**
     * Filter, which Workout to fetch.
     */
    where?: WorkoutWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Workouts to fetch.
     */
    orderBy?: WorkoutOrderByWithRelationInput | WorkoutOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Workouts.
     */
    cursor?: WorkoutWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Workouts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Workouts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Workouts.
     */
    distinct?: WorkoutScalarFieldEnum | WorkoutScalarFieldEnum[]
  }

  /**
   * Workout findMany
   */
  export type WorkoutFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Workout
     */
    select?: WorkoutSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Workout
     */
    omit?: WorkoutOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutInclude<ExtArgs> | null
    /**
     * Filter, which Workouts to fetch.
     */
    where?: WorkoutWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Workouts to fetch.
     */
    orderBy?: WorkoutOrderByWithRelationInput | WorkoutOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Workouts.
     */
    cursor?: WorkoutWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Workouts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Workouts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Workouts.
     */
    distinct?: WorkoutScalarFieldEnum | WorkoutScalarFieldEnum[]
  }

  /**
   * Workout create
   */
  export type WorkoutCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Workout
     */
    select?: WorkoutSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Workout
     */
    omit?: WorkoutOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutInclude<ExtArgs> | null
    /**
     * The data needed to create a Workout.
     */
    data: XOR<WorkoutCreateInput, WorkoutUncheckedCreateInput>
  }

  /**
   * Workout createMany
   */
  export type WorkoutCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Workouts.
     */
    data: WorkoutCreateManyInput | WorkoutCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Workout createManyAndReturn
   */
  export type WorkoutCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Workout
     */
    select?: WorkoutSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Workout
     */
    omit?: WorkoutOmit<ExtArgs> | null
    /**
     * The data used to create many Workouts.
     */
    data: WorkoutCreateManyInput | WorkoutCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Workout update
   */
  export type WorkoutUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Workout
     */
    select?: WorkoutSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Workout
     */
    omit?: WorkoutOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutInclude<ExtArgs> | null
    /**
     * The data needed to update a Workout.
     */
    data: XOR<WorkoutUpdateInput, WorkoutUncheckedUpdateInput>
    /**
     * Choose, which Workout to update.
     */
    where: WorkoutWhereUniqueInput
  }

  /**
   * Workout updateMany
   */
  export type WorkoutUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Workouts.
     */
    data: XOR<WorkoutUpdateManyMutationInput, WorkoutUncheckedUpdateManyInput>
    /**
     * Filter which Workouts to update
     */
    where?: WorkoutWhereInput
    /**
     * Limit how many Workouts to update.
     */
    limit?: number
  }

  /**
   * Workout updateManyAndReturn
   */
  export type WorkoutUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Workout
     */
    select?: WorkoutSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Workout
     */
    omit?: WorkoutOmit<ExtArgs> | null
    /**
     * The data used to update Workouts.
     */
    data: XOR<WorkoutUpdateManyMutationInput, WorkoutUncheckedUpdateManyInput>
    /**
     * Filter which Workouts to update
     */
    where?: WorkoutWhereInput
    /**
     * Limit how many Workouts to update.
     */
    limit?: number
  }

  /**
   * Workout upsert
   */
  export type WorkoutUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Workout
     */
    select?: WorkoutSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Workout
     */
    omit?: WorkoutOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutInclude<ExtArgs> | null
    /**
     * The filter to search for the Workout to update in case it exists.
     */
    where: WorkoutWhereUniqueInput
    /**
     * In case the Workout found by the `where` argument doesn't exist, create a new Workout with this data.
     */
    create: XOR<WorkoutCreateInput, WorkoutUncheckedCreateInput>
    /**
     * In case the Workout was found with the provided `where` argument, update it with this data.
     */
    update: XOR<WorkoutUpdateInput, WorkoutUncheckedUpdateInput>
  }

  /**
   * Workout delete
   */
  export type WorkoutDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Workout
     */
    select?: WorkoutSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Workout
     */
    omit?: WorkoutOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutInclude<ExtArgs> | null
    /**
     * Filter which Workout to delete.
     */
    where: WorkoutWhereUniqueInput
  }

  /**
   * Workout deleteMany
   */
  export type WorkoutDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Workouts to delete
     */
    where?: WorkoutWhereInput
    /**
     * Limit how many Workouts to delete.
     */
    limit?: number
  }

  /**
   * Workout.planWorkouts
   */
  export type Workout$planWorkoutsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanWorkout
     */
    select?: PlanWorkoutSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlanWorkout
     */
    omit?: PlanWorkoutOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanWorkoutInclude<ExtArgs> | null
    where?: PlanWorkoutWhereInput
    orderBy?: PlanWorkoutOrderByWithRelationInput | PlanWorkoutOrderByWithRelationInput[]
    cursor?: PlanWorkoutWhereUniqueInput
    take?: number
    skip?: number
    distinct?: PlanWorkoutScalarFieldEnum | PlanWorkoutScalarFieldEnum[]
  }

  /**
   * Workout.progressEntries
   */
  export type Workout$progressEntriesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProgressEntry
     */
    select?: ProgressEntrySelect<ExtArgs> | null
    /**
     * Omit specific fields from the ProgressEntry
     */
    omit?: ProgressEntryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProgressEntryInclude<ExtArgs> | null
    where?: ProgressEntryWhereInput
    orderBy?: ProgressEntryOrderByWithRelationInput | ProgressEntryOrderByWithRelationInput[]
    cursor?: ProgressEntryWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ProgressEntryScalarFieldEnum | ProgressEntryScalarFieldEnum[]
  }

  /**
   * Workout without action
   */
  export type WorkoutDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Workout
     */
    select?: WorkoutSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Workout
     */
    omit?: WorkoutOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutInclude<ExtArgs> | null
  }


  /**
   * Model WorkoutPlan
   */

  export type AggregateWorkoutPlan = {
    _count: WorkoutPlanCountAggregateOutputType | null
    _avg: WorkoutPlanAvgAggregateOutputType | null
    _sum: WorkoutPlanSumAggregateOutputType | null
    _min: WorkoutPlanMinAggregateOutputType | null
    _max: WorkoutPlanMaxAggregateOutputType | null
  }

  export type WorkoutPlanAvgAggregateOutputType = {
    id: number | null
    user_id: number | null
    duration_weeks: number | null
  }

  export type WorkoutPlanSumAggregateOutputType = {
    id: number | null
    user_id: number | null
    duration_weeks: number | null
  }

  export type WorkoutPlanMinAggregateOutputType = {
    id: number | null
    user_id: number | null
    title: string | null
    goal: string | null
    duration_weeks: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type WorkoutPlanMaxAggregateOutputType = {
    id: number | null
    user_id: number | null
    title: string | null
    goal: string | null
    duration_weeks: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type WorkoutPlanCountAggregateOutputType = {
    id: number
    user_id: number
    title: number
    goal: number
    duration_weeks: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type WorkoutPlanAvgAggregateInputType = {
    id?: true
    user_id?: true
    duration_weeks?: true
  }

  export type WorkoutPlanSumAggregateInputType = {
    id?: true
    user_id?: true
    duration_weeks?: true
  }

  export type WorkoutPlanMinAggregateInputType = {
    id?: true
    user_id?: true
    title?: true
    goal?: true
    duration_weeks?: true
    createdAt?: true
    updatedAt?: true
  }

  export type WorkoutPlanMaxAggregateInputType = {
    id?: true
    user_id?: true
    title?: true
    goal?: true
    duration_weeks?: true
    createdAt?: true
    updatedAt?: true
  }

  export type WorkoutPlanCountAggregateInputType = {
    id?: true
    user_id?: true
    title?: true
    goal?: true
    duration_weeks?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type WorkoutPlanAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which WorkoutPlan to aggregate.
     */
    where?: WorkoutPlanWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WorkoutPlans to fetch.
     */
    orderBy?: WorkoutPlanOrderByWithRelationInput | WorkoutPlanOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: WorkoutPlanWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WorkoutPlans from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WorkoutPlans.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned WorkoutPlans
    **/
    _count?: true | WorkoutPlanCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: WorkoutPlanAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: WorkoutPlanSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: WorkoutPlanMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: WorkoutPlanMaxAggregateInputType
  }

  export type GetWorkoutPlanAggregateType<T extends WorkoutPlanAggregateArgs> = {
        [P in keyof T & keyof AggregateWorkoutPlan]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateWorkoutPlan[P]>
      : GetScalarType<T[P], AggregateWorkoutPlan[P]>
  }




  export type WorkoutPlanGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: WorkoutPlanWhereInput
    orderBy?: WorkoutPlanOrderByWithAggregationInput | WorkoutPlanOrderByWithAggregationInput[]
    by: WorkoutPlanScalarFieldEnum[] | WorkoutPlanScalarFieldEnum
    having?: WorkoutPlanScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: WorkoutPlanCountAggregateInputType | true
    _avg?: WorkoutPlanAvgAggregateInputType
    _sum?: WorkoutPlanSumAggregateInputType
    _min?: WorkoutPlanMinAggregateInputType
    _max?: WorkoutPlanMaxAggregateInputType
  }

  export type WorkoutPlanGroupByOutputType = {
    id: number
    user_id: number
    title: string
    goal: string
    duration_weeks: number
    createdAt: Date
    updatedAt: Date
    _count: WorkoutPlanCountAggregateOutputType | null
    _avg: WorkoutPlanAvgAggregateOutputType | null
    _sum: WorkoutPlanSumAggregateOutputType | null
    _min: WorkoutPlanMinAggregateOutputType | null
    _max: WorkoutPlanMaxAggregateOutputType | null
  }

  type GetWorkoutPlanGroupByPayload<T extends WorkoutPlanGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<WorkoutPlanGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof WorkoutPlanGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], WorkoutPlanGroupByOutputType[P]>
            : GetScalarType<T[P], WorkoutPlanGroupByOutputType[P]>
        }
      >
    >


  export type WorkoutPlanSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    user_id?: boolean
    title?: boolean
    goal?: boolean
    duration_weeks?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    planWorkouts?: boolean | WorkoutPlan$planWorkoutsArgs<ExtArgs>
    _count?: boolean | WorkoutPlanCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["workoutPlan"]>

  export type WorkoutPlanSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    user_id?: boolean
    title?: boolean
    goal?: boolean
    duration_weeks?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["workoutPlan"]>

  export type WorkoutPlanSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    user_id?: boolean
    title?: boolean
    goal?: boolean
    duration_weeks?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["workoutPlan"]>

  export type WorkoutPlanSelectScalar = {
    id?: boolean
    user_id?: boolean
    title?: boolean
    goal?: boolean
    duration_weeks?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type WorkoutPlanOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "user_id" | "title" | "goal" | "duration_weeks" | "createdAt" | "updatedAt", ExtArgs["result"]["workoutPlan"]>
  export type WorkoutPlanInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    planWorkouts?: boolean | WorkoutPlan$planWorkoutsArgs<ExtArgs>
    _count?: boolean | WorkoutPlanCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type WorkoutPlanIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type WorkoutPlanIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }

  export type $WorkoutPlanPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "WorkoutPlan"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
      planWorkouts: Prisma.$PlanWorkoutPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      user_id: number
      title: string
      goal: string
      duration_weeks: number
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["workoutPlan"]>
    composites: {}
  }

  type WorkoutPlanGetPayload<S extends boolean | null | undefined | WorkoutPlanDefaultArgs> = $Result.GetResult<Prisma.$WorkoutPlanPayload, S>

  type WorkoutPlanCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<WorkoutPlanFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: WorkoutPlanCountAggregateInputType | true
    }

  export interface WorkoutPlanDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['WorkoutPlan'], meta: { name: 'WorkoutPlan' } }
    /**
     * Find zero or one WorkoutPlan that matches the filter.
     * @param {WorkoutPlanFindUniqueArgs} args - Arguments to find a WorkoutPlan
     * @example
     * // Get one WorkoutPlan
     * const workoutPlan = await prisma.workoutPlan.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends WorkoutPlanFindUniqueArgs>(args: SelectSubset<T, WorkoutPlanFindUniqueArgs<ExtArgs>>): Prisma__WorkoutPlanClient<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one WorkoutPlan that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {WorkoutPlanFindUniqueOrThrowArgs} args - Arguments to find a WorkoutPlan
     * @example
     * // Get one WorkoutPlan
     * const workoutPlan = await prisma.workoutPlan.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends WorkoutPlanFindUniqueOrThrowArgs>(args: SelectSubset<T, WorkoutPlanFindUniqueOrThrowArgs<ExtArgs>>): Prisma__WorkoutPlanClient<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first WorkoutPlan that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutPlanFindFirstArgs} args - Arguments to find a WorkoutPlan
     * @example
     * // Get one WorkoutPlan
     * const workoutPlan = await prisma.workoutPlan.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends WorkoutPlanFindFirstArgs>(args?: SelectSubset<T, WorkoutPlanFindFirstArgs<ExtArgs>>): Prisma__WorkoutPlanClient<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first WorkoutPlan that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutPlanFindFirstOrThrowArgs} args - Arguments to find a WorkoutPlan
     * @example
     * // Get one WorkoutPlan
     * const workoutPlan = await prisma.workoutPlan.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends WorkoutPlanFindFirstOrThrowArgs>(args?: SelectSubset<T, WorkoutPlanFindFirstOrThrowArgs<ExtArgs>>): Prisma__WorkoutPlanClient<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more WorkoutPlans that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutPlanFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all WorkoutPlans
     * const workoutPlans = await prisma.workoutPlan.findMany()
     * 
     * // Get first 10 WorkoutPlans
     * const workoutPlans = await prisma.workoutPlan.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const workoutPlanWithIdOnly = await prisma.workoutPlan.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends WorkoutPlanFindManyArgs>(args?: SelectSubset<T, WorkoutPlanFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a WorkoutPlan.
     * @param {WorkoutPlanCreateArgs} args - Arguments to create a WorkoutPlan.
     * @example
     * // Create one WorkoutPlan
     * const WorkoutPlan = await prisma.workoutPlan.create({
     *   data: {
     *     // ... data to create a WorkoutPlan
     *   }
     * })
     * 
     */
    create<T extends WorkoutPlanCreateArgs>(args: SelectSubset<T, WorkoutPlanCreateArgs<ExtArgs>>): Prisma__WorkoutPlanClient<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many WorkoutPlans.
     * @param {WorkoutPlanCreateManyArgs} args - Arguments to create many WorkoutPlans.
     * @example
     * // Create many WorkoutPlans
     * const workoutPlan = await prisma.workoutPlan.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends WorkoutPlanCreateManyArgs>(args?: SelectSubset<T, WorkoutPlanCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many WorkoutPlans and returns the data saved in the database.
     * @param {WorkoutPlanCreateManyAndReturnArgs} args - Arguments to create many WorkoutPlans.
     * @example
     * // Create many WorkoutPlans
     * const workoutPlan = await prisma.workoutPlan.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many WorkoutPlans and only return the `id`
     * const workoutPlanWithIdOnly = await prisma.workoutPlan.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends WorkoutPlanCreateManyAndReturnArgs>(args?: SelectSubset<T, WorkoutPlanCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a WorkoutPlan.
     * @param {WorkoutPlanDeleteArgs} args - Arguments to delete one WorkoutPlan.
     * @example
     * // Delete one WorkoutPlan
     * const WorkoutPlan = await prisma.workoutPlan.delete({
     *   where: {
     *     // ... filter to delete one WorkoutPlan
     *   }
     * })
     * 
     */
    delete<T extends WorkoutPlanDeleteArgs>(args: SelectSubset<T, WorkoutPlanDeleteArgs<ExtArgs>>): Prisma__WorkoutPlanClient<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one WorkoutPlan.
     * @param {WorkoutPlanUpdateArgs} args - Arguments to update one WorkoutPlan.
     * @example
     * // Update one WorkoutPlan
     * const workoutPlan = await prisma.workoutPlan.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends WorkoutPlanUpdateArgs>(args: SelectSubset<T, WorkoutPlanUpdateArgs<ExtArgs>>): Prisma__WorkoutPlanClient<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more WorkoutPlans.
     * @param {WorkoutPlanDeleteManyArgs} args - Arguments to filter WorkoutPlans to delete.
     * @example
     * // Delete a few WorkoutPlans
     * const { count } = await prisma.workoutPlan.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends WorkoutPlanDeleteManyArgs>(args?: SelectSubset<T, WorkoutPlanDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more WorkoutPlans.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutPlanUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many WorkoutPlans
     * const workoutPlan = await prisma.workoutPlan.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends WorkoutPlanUpdateManyArgs>(args: SelectSubset<T, WorkoutPlanUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more WorkoutPlans and returns the data updated in the database.
     * @param {WorkoutPlanUpdateManyAndReturnArgs} args - Arguments to update many WorkoutPlans.
     * @example
     * // Update many WorkoutPlans
     * const workoutPlan = await prisma.workoutPlan.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more WorkoutPlans and only return the `id`
     * const workoutPlanWithIdOnly = await prisma.workoutPlan.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends WorkoutPlanUpdateManyAndReturnArgs>(args: SelectSubset<T, WorkoutPlanUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one WorkoutPlan.
     * @param {WorkoutPlanUpsertArgs} args - Arguments to update or create a WorkoutPlan.
     * @example
     * // Update or create a WorkoutPlan
     * const workoutPlan = await prisma.workoutPlan.upsert({
     *   create: {
     *     // ... data to create a WorkoutPlan
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the WorkoutPlan we want to update
     *   }
     * })
     */
    upsert<T extends WorkoutPlanUpsertArgs>(args: SelectSubset<T, WorkoutPlanUpsertArgs<ExtArgs>>): Prisma__WorkoutPlanClient<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of WorkoutPlans.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutPlanCountArgs} args - Arguments to filter WorkoutPlans to count.
     * @example
     * // Count the number of WorkoutPlans
     * const count = await prisma.workoutPlan.count({
     *   where: {
     *     // ... the filter for the WorkoutPlans we want to count
     *   }
     * })
    **/
    count<T extends WorkoutPlanCountArgs>(
      args?: Subset<T, WorkoutPlanCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], WorkoutPlanCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a WorkoutPlan.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutPlanAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends WorkoutPlanAggregateArgs>(args: Subset<T, WorkoutPlanAggregateArgs>): Prisma.PrismaPromise<GetWorkoutPlanAggregateType<T>>

    /**
     * Group by WorkoutPlan.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutPlanGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends WorkoutPlanGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: WorkoutPlanGroupByArgs['orderBy'] }
        : { orderBy?: WorkoutPlanGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, WorkoutPlanGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetWorkoutPlanGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the WorkoutPlan model
   */
  readonly fields: WorkoutPlanFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for WorkoutPlan.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__WorkoutPlanClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    planWorkouts<T extends WorkoutPlan$planWorkoutsArgs<ExtArgs> = {}>(args?: Subset<T, WorkoutPlan$planWorkoutsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PlanWorkoutPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the WorkoutPlan model
   */
  interface WorkoutPlanFieldRefs {
    readonly id: FieldRef<"WorkoutPlan", 'Int'>
    readonly user_id: FieldRef<"WorkoutPlan", 'Int'>
    readonly title: FieldRef<"WorkoutPlan", 'String'>
    readonly goal: FieldRef<"WorkoutPlan", 'String'>
    readonly duration_weeks: FieldRef<"WorkoutPlan", 'Int'>
    readonly createdAt: FieldRef<"WorkoutPlan", 'DateTime'>
    readonly updatedAt: FieldRef<"WorkoutPlan", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * WorkoutPlan findUnique
   */
  export type WorkoutPlanFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanInclude<ExtArgs> | null
    /**
     * Filter, which WorkoutPlan to fetch.
     */
    where: WorkoutPlanWhereUniqueInput
  }

  /**
   * WorkoutPlan findUniqueOrThrow
   */
  export type WorkoutPlanFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanInclude<ExtArgs> | null
    /**
     * Filter, which WorkoutPlan to fetch.
     */
    where: WorkoutPlanWhereUniqueInput
  }

  /**
   * WorkoutPlan findFirst
   */
  export type WorkoutPlanFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanInclude<ExtArgs> | null
    /**
     * Filter, which WorkoutPlan to fetch.
     */
    where?: WorkoutPlanWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WorkoutPlans to fetch.
     */
    orderBy?: WorkoutPlanOrderByWithRelationInput | WorkoutPlanOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for WorkoutPlans.
     */
    cursor?: WorkoutPlanWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WorkoutPlans from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WorkoutPlans.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of WorkoutPlans.
     */
    distinct?: WorkoutPlanScalarFieldEnum | WorkoutPlanScalarFieldEnum[]
  }

  /**
   * WorkoutPlan findFirstOrThrow
   */
  export type WorkoutPlanFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanInclude<ExtArgs> | null
    /**
     * Filter, which WorkoutPlan to fetch.
     */
    where?: WorkoutPlanWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WorkoutPlans to fetch.
     */
    orderBy?: WorkoutPlanOrderByWithRelationInput | WorkoutPlanOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for WorkoutPlans.
     */
    cursor?: WorkoutPlanWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WorkoutPlans from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WorkoutPlans.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of WorkoutPlans.
     */
    distinct?: WorkoutPlanScalarFieldEnum | WorkoutPlanScalarFieldEnum[]
  }

  /**
   * WorkoutPlan findMany
   */
  export type WorkoutPlanFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanInclude<ExtArgs> | null
    /**
     * Filter, which WorkoutPlans to fetch.
     */
    where?: WorkoutPlanWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WorkoutPlans to fetch.
     */
    orderBy?: WorkoutPlanOrderByWithRelationInput | WorkoutPlanOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing WorkoutPlans.
     */
    cursor?: WorkoutPlanWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WorkoutPlans from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WorkoutPlans.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of WorkoutPlans.
     */
    distinct?: WorkoutPlanScalarFieldEnum | WorkoutPlanScalarFieldEnum[]
  }

  /**
   * WorkoutPlan create
   */
  export type WorkoutPlanCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanInclude<ExtArgs> | null
    /**
     * The data needed to create a WorkoutPlan.
     */
    data: XOR<WorkoutPlanCreateInput, WorkoutPlanUncheckedCreateInput>
  }

  /**
   * WorkoutPlan createMany
   */
  export type WorkoutPlanCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many WorkoutPlans.
     */
    data: WorkoutPlanCreateManyInput | WorkoutPlanCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * WorkoutPlan createManyAndReturn
   */
  export type WorkoutPlanCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * The data used to create many WorkoutPlans.
     */
    data: WorkoutPlanCreateManyInput | WorkoutPlanCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * WorkoutPlan update
   */
  export type WorkoutPlanUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanInclude<ExtArgs> | null
    /**
     * The data needed to update a WorkoutPlan.
     */
    data: XOR<WorkoutPlanUpdateInput, WorkoutPlanUncheckedUpdateInput>
    /**
     * Choose, which WorkoutPlan to update.
     */
    where: WorkoutPlanWhereUniqueInput
  }

  /**
   * WorkoutPlan updateMany
   */
  export type WorkoutPlanUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update WorkoutPlans.
     */
    data: XOR<WorkoutPlanUpdateManyMutationInput, WorkoutPlanUncheckedUpdateManyInput>
    /**
     * Filter which WorkoutPlans to update
     */
    where?: WorkoutPlanWhereInput
    /**
     * Limit how many WorkoutPlans to update.
     */
    limit?: number
  }

  /**
   * WorkoutPlan updateManyAndReturn
   */
  export type WorkoutPlanUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * The data used to update WorkoutPlans.
     */
    data: XOR<WorkoutPlanUpdateManyMutationInput, WorkoutPlanUncheckedUpdateManyInput>
    /**
     * Filter which WorkoutPlans to update
     */
    where?: WorkoutPlanWhereInput
    /**
     * Limit how many WorkoutPlans to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * WorkoutPlan upsert
   */
  export type WorkoutPlanUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanInclude<ExtArgs> | null
    /**
     * The filter to search for the WorkoutPlan to update in case it exists.
     */
    where: WorkoutPlanWhereUniqueInput
    /**
     * In case the WorkoutPlan found by the `where` argument doesn't exist, create a new WorkoutPlan with this data.
     */
    create: XOR<WorkoutPlanCreateInput, WorkoutPlanUncheckedCreateInput>
    /**
     * In case the WorkoutPlan was found with the provided `where` argument, update it with this data.
     */
    update: XOR<WorkoutPlanUpdateInput, WorkoutPlanUncheckedUpdateInput>
  }

  /**
   * WorkoutPlan delete
   */
  export type WorkoutPlanDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanInclude<ExtArgs> | null
    /**
     * Filter which WorkoutPlan to delete.
     */
    where: WorkoutPlanWhereUniqueInput
  }

  /**
   * WorkoutPlan deleteMany
   */
  export type WorkoutPlanDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which WorkoutPlans to delete
     */
    where?: WorkoutPlanWhereInput
    /**
     * Limit how many WorkoutPlans to delete.
     */
    limit?: number
  }

  /**
   * WorkoutPlan.planWorkouts
   */
  export type WorkoutPlan$planWorkoutsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanWorkout
     */
    select?: PlanWorkoutSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlanWorkout
     */
    omit?: PlanWorkoutOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanWorkoutInclude<ExtArgs> | null
    where?: PlanWorkoutWhereInput
    orderBy?: PlanWorkoutOrderByWithRelationInput | PlanWorkoutOrderByWithRelationInput[]
    cursor?: PlanWorkoutWhereUniqueInput
    take?: number
    skip?: number
    distinct?: PlanWorkoutScalarFieldEnum | PlanWorkoutScalarFieldEnum[]
  }

  /**
   * WorkoutPlan without action
   */
  export type WorkoutPlanDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanInclude<ExtArgs> | null
  }


  /**
   * Model PlanWorkout
   */

  export type AggregatePlanWorkout = {
    _count: PlanWorkoutCountAggregateOutputType | null
    _avg: PlanWorkoutAvgAggregateOutputType | null
    _sum: PlanWorkoutSumAggregateOutputType | null
    _min: PlanWorkoutMinAggregateOutputType | null
    _max: PlanWorkoutMaxAggregateOutputType | null
  }

  export type PlanWorkoutAvgAggregateOutputType = {
    plan_id: number | null
    workout_id: number | null
    day_number: number | null
  }

  export type PlanWorkoutSumAggregateOutputType = {
    plan_id: number | null
    workout_id: number | null
    day_number: number | null
  }

  export type PlanWorkoutMinAggregateOutputType = {
    plan_id: number | null
    workout_id: number | null
    day_number: number | null
  }

  export type PlanWorkoutMaxAggregateOutputType = {
    plan_id: number | null
    workout_id: number | null
    day_number: number | null
  }

  export type PlanWorkoutCountAggregateOutputType = {
    plan_id: number
    workout_id: number
    day_number: number
    _all: number
  }


  export type PlanWorkoutAvgAggregateInputType = {
    plan_id?: true
    workout_id?: true
    day_number?: true
  }

  export type PlanWorkoutSumAggregateInputType = {
    plan_id?: true
    workout_id?: true
    day_number?: true
  }

  export type PlanWorkoutMinAggregateInputType = {
    plan_id?: true
    workout_id?: true
    day_number?: true
  }

  export type PlanWorkoutMaxAggregateInputType = {
    plan_id?: true
    workout_id?: true
    day_number?: true
  }

  export type PlanWorkoutCountAggregateInputType = {
    plan_id?: true
    workout_id?: true
    day_number?: true
    _all?: true
  }

  export type PlanWorkoutAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PlanWorkout to aggregate.
     */
    where?: PlanWorkoutWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PlanWorkouts to fetch.
     */
    orderBy?: PlanWorkoutOrderByWithRelationInput | PlanWorkoutOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: PlanWorkoutWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PlanWorkouts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PlanWorkouts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned PlanWorkouts
    **/
    _count?: true | PlanWorkoutCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: PlanWorkoutAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: PlanWorkoutSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: PlanWorkoutMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: PlanWorkoutMaxAggregateInputType
  }

  export type GetPlanWorkoutAggregateType<T extends PlanWorkoutAggregateArgs> = {
        [P in keyof T & keyof AggregatePlanWorkout]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregatePlanWorkout[P]>
      : GetScalarType<T[P], AggregatePlanWorkout[P]>
  }




  export type PlanWorkoutGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PlanWorkoutWhereInput
    orderBy?: PlanWorkoutOrderByWithAggregationInput | PlanWorkoutOrderByWithAggregationInput[]
    by: PlanWorkoutScalarFieldEnum[] | PlanWorkoutScalarFieldEnum
    having?: PlanWorkoutScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: PlanWorkoutCountAggregateInputType | true
    _avg?: PlanWorkoutAvgAggregateInputType
    _sum?: PlanWorkoutSumAggregateInputType
    _min?: PlanWorkoutMinAggregateInputType
    _max?: PlanWorkoutMaxAggregateInputType
  }

  export type PlanWorkoutGroupByOutputType = {
    plan_id: number
    workout_id: number
    day_number: number
    _count: PlanWorkoutCountAggregateOutputType | null
    _avg: PlanWorkoutAvgAggregateOutputType | null
    _sum: PlanWorkoutSumAggregateOutputType | null
    _min: PlanWorkoutMinAggregateOutputType | null
    _max: PlanWorkoutMaxAggregateOutputType | null
  }

  type GetPlanWorkoutGroupByPayload<T extends PlanWorkoutGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<PlanWorkoutGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof PlanWorkoutGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], PlanWorkoutGroupByOutputType[P]>
            : GetScalarType<T[P], PlanWorkoutGroupByOutputType[P]>
        }
      >
    >


  export type PlanWorkoutSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    plan_id?: boolean
    workout_id?: boolean
    day_number?: boolean
    plan?: boolean | WorkoutPlanDefaultArgs<ExtArgs>
    workout?: boolean | WorkoutDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["planWorkout"]>

  export type PlanWorkoutSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    plan_id?: boolean
    workout_id?: boolean
    day_number?: boolean
    plan?: boolean | WorkoutPlanDefaultArgs<ExtArgs>
    workout?: boolean | WorkoutDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["planWorkout"]>

  export type PlanWorkoutSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    plan_id?: boolean
    workout_id?: boolean
    day_number?: boolean
    plan?: boolean | WorkoutPlanDefaultArgs<ExtArgs>
    workout?: boolean | WorkoutDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["planWorkout"]>

  export type PlanWorkoutSelectScalar = {
    plan_id?: boolean
    workout_id?: boolean
    day_number?: boolean
  }

  export type PlanWorkoutOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"plan_id" | "workout_id" | "day_number", ExtArgs["result"]["planWorkout"]>
  export type PlanWorkoutInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    plan?: boolean | WorkoutPlanDefaultArgs<ExtArgs>
    workout?: boolean | WorkoutDefaultArgs<ExtArgs>
  }
  export type PlanWorkoutIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    plan?: boolean | WorkoutPlanDefaultArgs<ExtArgs>
    workout?: boolean | WorkoutDefaultArgs<ExtArgs>
  }
  export type PlanWorkoutIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    plan?: boolean | WorkoutPlanDefaultArgs<ExtArgs>
    workout?: boolean | WorkoutDefaultArgs<ExtArgs>
  }

  export type $PlanWorkoutPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "PlanWorkout"
    objects: {
      plan: Prisma.$WorkoutPlanPayload<ExtArgs>
      workout: Prisma.$WorkoutPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      plan_id: number
      workout_id: number
      day_number: number
    }, ExtArgs["result"]["planWorkout"]>
    composites: {}
  }

  type PlanWorkoutGetPayload<S extends boolean | null | undefined | PlanWorkoutDefaultArgs> = $Result.GetResult<Prisma.$PlanWorkoutPayload, S>

  type PlanWorkoutCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<PlanWorkoutFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: PlanWorkoutCountAggregateInputType | true
    }

  export interface PlanWorkoutDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['PlanWorkout'], meta: { name: 'PlanWorkout' } }
    /**
     * Find zero or one PlanWorkout that matches the filter.
     * @param {PlanWorkoutFindUniqueArgs} args - Arguments to find a PlanWorkout
     * @example
     * // Get one PlanWorkout
     * const planWorkout = await prisma.planWorkout.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends PlanWorkoutFindUniqueArgs>(args: SelectSubset<T, PlanWorkoutFindUniqueArgs<ExtArgs>>): Prisma__PlanWorkoutClient<$Result.GetResult<Prisma.$PlanWorkoutPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one PlanWorkout that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {PlanWorkoutFindUniqueOrThrowArgs} args - Arguments to find a PlanWorkout
     * @example
     * // Get one PlanWorkout
     * const planWorkout = await prisma.planWorkout.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends PlanWorkoutFindUniqueOrThrowArgs>(args: SelectSubset<T, PlanWorkoutFindUniqueOrThrowArgs<ExtArgs>>): Prisma__PlanWorkoutClient<$Result.GetResult<Prisma.$PlanWorkoutPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PlanWorkout that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlanWorkoutFindFirstArgs} args - Arguments to find a PlanWorkout
     * @example
     * // Get one PlanWorkout
     * const planWorkout = await prisma.planWorkout.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends PlanWorkoutFindFirstArgs>(args?: SelectSubset<T, PlanWorkoutFindFirstArgs<ExtArgs>>): Prisma__PlanWorkoutClient<$Result.GetResult<Prisma.$PlanWorkoutPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PlanWorkout that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlanWorkoutFindFirstOrThrowArgs} args - Arguments to find a PlanWorkout
     * @example
     * // Get one PlanWorkout
     * const planWorkout = await prisma.planWorkout.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends PlanWorkoutFindFirstOrThrowArgs>(args?: SelectSubset<T, PlanWorkoutFindFirstOrThrowArgs<ExtArgs>>): Prisma__PlanWorkoutClient<$Result.GetResult<Prisma.$PlanWorkoutPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more PlanWorkouts that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlanWorkoutFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all PlanWorkouts
     * const planWorkouts = await prisma.planWorkout.findMany()
     * 
     * // Get first 10 PlanWorkouts
     * const planWorkouts = await prisma.planWorkout.findMany({ take: 10 })
     * 
     * // Only select the `plan_id`
     * const planWorkoutWithPlan_idOnly = await prisma.planWorkout.findMany({ select: { plan_id: true } })
     * 
     */
    findMany<T extends PlanWorkoutFindManyArgs>(args?: SelectSubset<T, PlanWorkoutFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PlanWorkoutPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a PlanWorkout.
     * @param {PlanWorkoutCreateArgs} args - Arguments to create a PlanWorkout.
     * @example
     * // Create one PlanWorkout
     * const PlanWorkout = await prisma.planWorkout.create({
     *   data: {
     *     // ... data to create a PlanWorkout
     *   }
     * })
     * 
     */
    create<T extends PlanWorkoutCreateArgs>(args: SelectSubset<T, PlanWorkoutCreateArgs<ExtArgs>>): Prisma__PlanWorkoutClient<$Result.GetResult<Prisma.$PlanWorkoutPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many PlanWorkouts.
     * @param {PlanWorkoutCreateManyArgs} args - Arguments to create many PlanWorkouts.
     * @example
     * // Create many PlanWorkouts
     * const planWorkout = await prisma.planWorkout.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends PlanWorkoutCreateManyArgs>(args?: SelectSubset<T, PlanWorkoutCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many PlanWorkouts and returns the data saved in the database.
     * @param {PlanWorkoutCreateManyAndReturnArgs} args - Arguments to create many PlanWorkouts.
     * @example
     * // Create many PlanWorkouts
     * const planWorkout = await prisma.planWorkout.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many PlanWorkouts and only return the `plan_id`
     * const planWorkoutWithPlan_idOnly = await prisma.planWorkout.createManyAndReturn({
     *   select: { plan_id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends PlanWorkoutCreateManyAndReturnArgs>(args?: SelectSubset<T, PlanWorkoutCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PlanWorkoutPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a PlanWorkout.
     * @param {PlanWorkoutDeleteArgs} args - Arguments to delete one PlanWorkout.
     * @example
     * // Delete one PlanWorkout
     * const PlanWorkout = await prisma.planWorkout.delete({
     *   where: {
     *     // ... filter to delete one PlanWorkout
     *   }
     * })
     * 
     */
    delete<T extends PlanWorkoutDeleteArgs>(args: SelectSubset<T, PlanWorkoutDeleteArgs<ExtArgs>>): Prisma__PlanWorkoutClient<$Result.GetResult<Prisma.$PlanWorkoutPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one PlanWorkout.
     * @param {PlanWorkoutUpdateArgs} args - Arguments to update one PlanWorkout.
     * @example
     * // Update one PlanWorkout
     * const planWorkout = await prisma.planWorkout.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends PlanWorkoutUpdateArgs>(args: SelectSubset<T, PlanWorkoutUpdateArgs<ExtArgs>>): Prisma__PlanWorkoutClient<$Result.GetResult<Prisma.$PlanWorkoutPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more PlanWorkouts.
     * @param {PlanWorkoutDeleteManyArgs} args - Arguments to filter PlanWorkouts to delete.
     * @example
     * // Delete a few PlanWorkouts
     * const { count } = await prisma.planWorkout.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends PlanWorkoutDeleteManyArgs>(args?: SelectSubset<T, PlanWorkoutDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more PlanWorkouts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlanWorkoutUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many PlanWorkouts
     * const planWorkout = await prisma.planWorkout.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends PlanWorkoutUpdateManyArgs>(args: SelectSubset<T, PlanWorkoutUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more PlanWorkouts and returns the data updated in the database.
     * @param {PlanWorkoutUpdateManyAndReturnArgs} args - Arguments to update many PlanWorkouts.
     * @example
     * // Update many PlanWorkouts
     * const planWorkout = await prisma.planWorkout.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more PlanWorkouts and only return the `plan_id`
     * const planWorkoutWithPlan_idOnly = await prisma.planWorkout.updateManyAndReturn({
     *   select: { plan_id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends PlanWorkoutUpdateManyAndReturnArgs>(args: SelectSubset<T, PlanWorkoutUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PlanWorkoutPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one PlanWorkout.
     * @param {PlanWorkoutUpsertArgs} args - Arguments to update or create a PlanWorkout.
     * @example
     * // Update or create a PlanWorkout
     * const planWorkout = await prisma.planWorkout.upsert({
     *   create: {
     *     // ... data to create a PlanWorkout
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the PlanWorkout we want to update
     *   }
     * })
     */
    upsert<T extends PlanWorkoutUpsertArgs>(args: SelectSubset<T, PlanWorkoutUpsertArgs<ExtArgs>>): Prisma__PlanWorkoutClient<$Result.GetResult<Prisma.$PlanWorkoutPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of PlanWorkouts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlanWorkoutCountArgs} args - Arguments to filter PlanWorkouts to count.
     * @example
     * // Count the number of PlanWorkouts
     * const count = await prisma.planWorkout.count({
     *   where: {
     *     // ... the filter for the PlanWorkouts we want to count
     *   }
     * })
    **/
    count<T extends PlanWorkoutCountArgs>(
      args?: Subset<T, PlanWorkoutCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], PlanWorkoutCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a PlanWorkout.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlanWorkoutAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends PlanWorkoutAggregateArgs>(args: Subset<T, PlanWorkoutAggregateArgs>): Prisma.PrismaPromise<GetPlanWorkoutAggregateType<T>>

    /**
     * Group by PlanWorkout.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlanWorkoutGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends PlanWorkoutGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: PlanWorkoutGroupByArgs['orderBy'] }
        : { orderBy?: PlanWorkoutGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, PlanWorkoutGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPlanWorkoutGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the PlanWorkout model
   */
  readonly fields: PlanWorkoutFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for PlanWorkout.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__PlanWorkoutClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    plan<T extends WorkoutPlanDefaultArgs<ExtArgs> = {}>(args?: Subset<T, WorkoutPlanDefaultArgs<ExtArgs>>): Prisma__WorkoutPlanClient<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    workout<T extends WorkoutDefaultArgs<ExtArgs> = {}>(args?: Subset<T, WorkoutDefaultArgs<ExtArgs>>): Prisma__WorkoutClient<$Result.GetResult<Prisma.$WorkoutPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the PlanWorkout model
   */
  interface PlanWorkoutFieldRefs {
    readonly plan_id: FieldRef<"PlanWorkout", 'Int'>
    readonly workout_id: FieldRef<"PlanWorkout", 'Int'>
    readonly day_number: FieldRef<"PlanWorkout", 'Int'>
  }
    

  // Custom InputTypes
  /**
   * PlanWorkout findUnique
   */
  export type PlanWorkoutFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanWorkout
     */
    select?: PlanWorkoutSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlanWorkout
     */
    omit?: PlanWorkoutOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanWorkoutInclude<ExtArgs> | null
    /**
     * Filter, which PlanWorkout to fetch.
     */
    where: PlanWorkoutWhereUniqueInput
  }

  /**
   * PlanWorkout findUniqueOrThrow
   */
  export type PlanWorkoutFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanWorkout
     */
    select?: PlanWorkoutSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlanWorkout
     */
    omit?: PlanWorkoutOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanWorkoutInclude<ExtArgs> | null
    /**
     * Filter, which PlanWorkout to fetch.
     */
    where: PlanWorkoutWhereUniqueInput
  }

  /**
   * PlanWorkout findFirst
   */
  export type PlanWorkoutFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanWorkout
     */
    select?: PlanWorkoutSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlanWorkout
     */
    omit?: PlanWorkoutOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanWorkoutInclude<ExtArgs> | null
    /**
     * Filter, which PlanWorkout to fetch.
     */
    where?: PlanWorkoutWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PlanWorkouts to fetch.
     */
    orderBy?: PlanWorkoutOrderByWithRelationInput | PlanWorkoutOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PlanWorkouts.
     */
    cursor?: PlanWorkoutWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PlanWorkouts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PlanWorkouts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PlanWorkouts.
     */
    distinct?: PlanWorkoutScalarFieldEnum | PlanWorkoutScalarFieldEnum[]
  }

  /**
   * PlanWorkout findFirstOrThrow
   */
  export type PlanWorkoutFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanWorkout
     */
    select?: PlanWorkoutSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlanWorkout
     */
    omit?: PlanWorkoutOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanWorkoutInclude<ExtArgs> | null
    /**
     * Filter, which PlanWorkout to fetch.
     */
    where?: PlanWorkoutWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PlanWorkouts to fetch.
     */
    orderBy?: PlanWorkoutOrderByWithRelationInput | PlanWorkoutOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PlanWorkouts.
     */
    cursor?: PlanWorkoutWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PlanWorkouts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PlanWorkouts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PlanWorkouts.
     */
    distinct?: PlanWorkoutScalarFieldEnum | PlanWorkoutScalarFieldEnum[]
  }

  /**
   * PlanWorkout findMany
   */
  export type PlanWorkoutFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanWorkout
     */
    select?: PlanWorkoutSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlanWorkout
     */
    omit?: PlanWorkoutOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanWorkoutInclude<ExtArgs> | null
    /**
     * Filter, which PlanWorkouts to fetch.
     */
    where?: PlanWorkoutWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PlanWorkouts to fetch.
     */
    orderBy?: PlanWorkoutOrderByWithRelationInput | PlanWorkoutOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing PlanWorkouts.
     */
    cursor?: PlanWorkoutWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PlanWorkouts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PlanWorkouts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PlanWorkouts.
     */
    distinct?: PlanWorkoutScalarFieldEnum | PlanWorkoutScalarFieldEnum[]
  }

  /**
   * PlanWorkout create
   */
  export type PlanWorkoutCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanWorkout
     */
    select?: PlanWorkoutSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlanWorkout
     */
    omit?: PlanWorkoutOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanWorkoutInclude<ExtArgs> | null
    /**
     * The data needed to create a PlanWorkout.
     */
    data: XOR<PlanWorkoutCreateInput, PlanWorkoutUncheckedCreateInput>
  }

  /**
   * PlanWorkout createMany
   */
  export type PlanWorkoutCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many PlanWorkouts.
     */
    data: PlanWorkoutCreateManyInput | PlanWorkoutCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * PlanWorkout createManyAndReturn
   */
  export type PlanWorkoutCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanWorkout
     */
    select?: PlanWorkoutSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the PlanWorkout
     */
    omit?: PlanWorkoutOmit<ExtArgs> | null
    /**
     * The data used to create many PlanWorkouts.
     */
    data: PlanWorkoutCreateManyInput | PlanWorkoutCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanWorkoutIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * PlanWorkout update
   */
  export type PlanWorkoutUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanWorkout
     */
    select?: PlanWorkoutSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlanWorkout
     */
    omit?: PlanWorkoutOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanWorkoutInclude<ExtArgs> | null
    /**
     * The data needed to update a PlanWorkout.
     */
    data: XOR<PlanWorkoutUpdateInput, PlanWorkoutUncheckedUpdateInput>
    /**
     * Choose, which PlanWorkout to update.
     */
    where: PlanWorkoutWhereUniqueInput
  }

  /**
   * PlanWorkout updateMany
   */
  export type PlanWorkoutUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update PlanWorkouts.
     */
    data: XOR<PlanWorkoutUpdateManyMutationInput, PlanWorkoutUncheckedUpdateManyInput>
    /**
     * Filter which PlanWorkouts to update
     */
    where?: PlanWorkoutWhereInput
    /**
     * Limit how many PlanWorkouts to update.
     */
    limit?: number
  }

  /**
   * PlanWorkout updateManyAndReturn
   */
  export type PlanWorkoutUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanWorkout
     */
    select?: PlanWorkoutSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the PlanWorkout
     */
    omit?: PlanWorkoutOmit<ExtArgs> | null
    /**
     * The data used to update PlanWorkouts.
     */
    data: XOR<PlanWorkoutUpdateManyMutationInput, PlanWorkoutUncheckedUpdateManyInput>
    /**
     * Filter which PlanWorkouts to update
     */
    where?: PlanWorkoutWhereInput
    /**
     * Limit how many PlanWorkouts to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanWorkoutIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * PlanWorkout upsert
   */
  export type PlanWorkoutUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanWorkout
     */
    select?: PlanWorkoutSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlanWorkout
     */
    omit?: PlanWorkoutOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanWorkoutInclude<ExtArgs> | null
    /**
     * The filter to search for the PlanWorkout to update in case it exists.
     */
    where: PlanWorkoutWhereUniqueInput
    /**
     * In case the PlanWorkout found by the `where` argument doesn't exist, create a new PlanWorkout with this data.
     */
    create: XOR<PlanWorkoutCreateInput, PlanWorkoutUncheckedCreateInput>
    /**
     * In case the PlanWorkout was found with the provided `where` argument, update it with this data.
     */
    update: XOR<PlanWorkoutUpdateInput, PlanWorkoutUncheckedUpdateInput>
  }

  /**
   * PlanWorkout delete
   */
  export type PlanWorkoutDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanWorkout
     */
    select?: PlanWorkoutSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlanWorkout
     */
    omit?: PlanWorkoutOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanWorkoutInclude<ExtArgs> | null
    /**
     * Filter which PlanWorkout to delete.
     */
    where: PlanWorkoutWhereUniqueInput
  }

  /**
   * PlanWorkout deleteMany
   */
  export type PlanWorkoutDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PlanWorkouts to delete
     */
    where?: PlanWorkoutWhereInput
    /**
     * Limit how many PlanWorkouts to delete.
     */
    limit?: number
  }

  /**
   * PlanWorkout without action
   */
  export type PlanWorkoutDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanWorkout
     */
    select?: PlanWorkoutSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlanWorkout
     */
    omit?: PlanWorkoutOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanWorkoutInclude<ExtArgs> | null
  }


  /**
   * Model ProgressEntry
   */

  export type AggregateProgressEntry = {
    _count: ProgressEntryCountAggregateOutputType | null
    _avg: ProgressEntryAvgAggregateOutputType | null
    _sum: ProgressEntrySumAggregateOutputType | null
    _min: ProgressEntryMinAggregateOutputType | null
    _max: ProgressEntryMaxAggregateOutputType | null
  }

  export type ProgressEntryAvgAggregateOutputType = {
    id: number | null
    user_id: number | null
    workout_id: number | null
  }

  export type ProgressEntrySumAggregateOutputType = {
    id: number | null
    user_id: number | null
    workout_id: number | null
  }

  export type ProgressEntryMinAggregateOutputType = {
    id: number | null
    user_id: number | null
    workout_id: number | null
    date_completed: Date | null
    notes: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type ProgressEntryMaxAggregateOutputType = {
    id: number | null
    user_id: number | null
    workout_id: number | null
    date_completed: Date | null
    notes: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type ProgressEntryCountAggregateOutputType = {
    id: number
    user_id: number
    workout_id: number
    date_completed: number
    notes: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type ProgressEntryAvgAggregateInputType = {
    id?: true
    user_id?: true
    workout_id?: true
  }

  export type ProgressEntrySumAggregateInputType = {
    id?: true
    user_id?: true
    workout_id?: true
  }

  export type ProgressEntryMinAggregateInputType = {
    id?: true
    user_id?: true
    workout_id?: true
    date_completed?: true
    notes?: true
    createdAt?: true
    updatedAt?: true
  }

  export type ProgressEntryMaxAggregateInputType = {
    id?: true
    user_id?: true
    workout_id?: true
    date_completed?: true
    notes?: true
    createdAt?: true
    updatedAt?: true
  }

  export type ProgressEntryCountAggregateInputType = {
    id?: true
    user_id?: true
    workout_id?: true
    date_completed?: true
    notes?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type ProgressEntryAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ProgressEntry to aggregate.
     */
    where?: ProgressEntryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ProgressEntries to fetch.
     */
    orderBy?: ProgressEntryOrderByWithRelationInput | ProgressEntryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ProgressEntryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ProgressEntries from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ProgressEntries.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned ProgressEntries
    **/
    _count?: true | ProgressEntryCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: ProgressEntryAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: ProgressEntrySumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ProgressEntryMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ProgressEntryMaxAggregateInputType
  }

  export type GetProgressEntryAggregateType<T extends ProgressEntryAggregateArgs> = {
        [P in keyof T & keyof AggregateProgressEntry]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateProgressEntry[P]>
      : GetScalarType<T[P], AggregateProgressEntry[P]>
  }




  export type ProgressEntryGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ProgressEntryWhereInput
    orderBy?: ProgressEntryOrderByWithAggregationInput | ProgressEntryOrderByWithAggregationInput[]
    by: ProgressEntryScalarFieldEnum[] | ProgressEntryScalarFieldEnum
    having?: ProgressEntryScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ProgressEntryCountAggregateInputType | true
    _avg?: ProgressEntryAvgAggregateInputType
    _sum?: ProgressEntrySumAggregateInputType
    _min?: ProgressEntryMinAggregateInputType
    _max?: ProgressEntryMaxAggregateInputType
  }

  export type ProgressEntryGroupByOutputType = {
    id: number
    user_id: number
    workout_id: number
    date_completed: Date
    notes: string | null
    createdAt: Date
    updatedAt: Date
    _count: ProgressEntryCountAggregateOutputType | null
    _avg: ProgressEntryAvgAggregateOutputType | null
    _sum: ProgressEntrySumAggregateOutputType | null
    _min: ProgressEntryMinAggregateOutputType | null
    _max: ProgressEntryMaxAggregateOutputType | null
  }

  type GetProgressEntryGroupByPayload<T extends ProgressEntryGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ProgressEntryGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ProgressEntryGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ProgressEntryGroupByOutputType[P]>
            : GetScalarType<T[P], ProgressEntryGroupByOutputType[P]>
        }
      >
    >


  export type ProgressEntrySelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    user_id?: boolean
    workout_id?: boolean
    date_completed?: boolean
    notes?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    workout?: boolean | WorkoutDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["progressEntry"]>

  export type ProgressEntrySelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    user_id?: boolean
    workout_id?: boolean
    date_completed?: boolean
    notes?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    workout?: boolean | WorkoutDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["progressEntry"]>

  export type ProgressEntrySelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    user_id?: boolean
    workout_id?: boolean
    date_completed?: boolean
    notes?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    workout?: boolean | WorkoutDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["progressEntry"]>

  export type ProgressEntrySelectScalar = {
    id?: boolean
    user_id?: boolean
    workout_id?: boolean
    date_completed?: boolean
    notes?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type ProgressEntryOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "user_id" | "workout_id" | "date_completed" | "notes" | "createdAt" | "updatedAt", ExtArgs["result"]["progressEntry"]>
  export type ProgressEntryInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    workout?: boolean | WorkoutDefaultArgs<ExtArgs>
  }
  export type ProgressEntryIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    workout?: boolean | WorkoutDefaultArgs<ExtArgs>
  }
  export type ProgressEntryIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    workout?: boolean | WorkoutDefaultArgs<ExtArgs>
  }

  export type $ProgressEntryPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "ProgressEntry"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
      workout: Prisma.$WorkoutPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      user_id: number
      workout_id: number
      date_completed: Date
      notes: string | null
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["progressEntry"]>
    composites: {}
  }

  type ProgressEntryGetPayload<S extends boolean | null | undefined | ProgressEntryDefaultArgs> = $Result.GetResult<Prisma.$ProgressEntryPayload, S>

  type ProgressEntryCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ProgressEntryFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ProgressEntryCountAggregateInputType | true
    }

  export interface ProgressEntryDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['ProgressEntry'], meta: { name: 'ProgressEntry' } }
    /**
     * Find zero or one ProgressEntry that matches the filter.
     * @param {ProgressEntryFindUniqueArgs} args - Arguments to find a ProgressEntry
     * @example
     * // Get one ProgressEntry
     * const progressEntry = await prisma.progressEntry.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ProgressEntryFindUniqueArgs>(args: SelectSubset<T, ProgressEntryFindUniqueArgs<ExtArgs>>): Prisma__ProgressEntryClient<$Result.GetResult<Prisma.$ProgressEntryPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one ProgressEntry that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ProgressEntryFindUniqueOrThrowArgs} args - Arguments to find a ProgressEntry
     * @example
     * // Get one ProgressEntry
     * const progressEntry = await prisma.progressEntry.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ProgressEntryFindUniqueOrThrowArgs>(args: SelectSubset<T, ProgressEntryFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ProgressEntryClient<$Result.GetResult<Prisma.$ProgressEntryPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first ProgressEntry that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProgressEntryFindFirstArgs} args - Arguments to find a ProgressEntry
     * @example
     * // Get one ProgressEntry
     * const progressEntry = await prisma.progressEntry.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ProgressEntryFindFirstArgs>(args?: SelectSubset<T, ProgressEntryFindFirstArgs<ExtArgs>>): Prisma__ProgressEntryClient<$Result.GetResult<Prisma.$ProgressEntryPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first ProgressEntry that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProgressEntryFindFirstOrThrowArgs} args - Arguments to find a ProgressEntry
     * @example
     * // Get one ProgressEntry
     * const progressEntry = await prisma.progressEntry.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ProgressEntryFindFirstOrThrowArgs>(args?: SelectSubset<T, ProgressEntryFindFirstOrThrowArgs<ExtArgs>>): Prisma__ProgressEntryClient<$Result.GetResult<Prisma.$ProgressEntryPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more ProgressEntries that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProgressEntryFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all ProgressEntries
     * const progressEntries = await prisma.progressEntry.findMany()
     * 
     * // Get first 10 ProgressEntries
     * const progressEntries = await prisma.progressEntry.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const progressEntryWithIdOnly = await prisma.progressEntry.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends ProgressEntryFindManyArgs>(args?: SelectSubset<T, ProgressEntryFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ProgressEntryPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a ProgressEntry.
     * @param {ProgressEntryCreateArgs} args - Arguments to create a ProgressEntry.
     * @example
     * // Create one ProgressEntry
     * const ProgressEntry = await prisma.progressEntry.create({
     *   data: {
     *     // ... data to create a ProgressEntry
     *   }
     * })
     * 
     */
    create<T extends ProgressEntryCreateArgs>(args: SelectSubset<T, ProgressEntryCreateArgs<ExtArgs>>): Prisma__ProgressEntryClient<$Result.GetResult<Prisma.$ProgressEntryPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many ProgressEntries.
     * @param {ProgressEntryCreateManyArgs} args - Arguments to create many ProgressEntries.
     * @example
     * // Create many ProgressEntries
     * const progressEntry = await prisma.progressEntry.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ProgressEntryCreateManyArgs>(args?: SelectSubset<T, ProgressEntryCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many ProgressEntries and returns the data saved in the database.
     * @param {ProgressEntryCreateManyAndReturnArgs} args - Arguments to create many ProgressEntries.
     * @example
     * // Create many ProgressEntries
     * const progressEntry = await prisma.progressEntry.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many ProgressEntries and only return the `id`
     * const progressEntryWithIdOnly = await prisma.progressEntry.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends ProgressEntryCreateManyAndReturnArgs>(args?: SelectSubset<T, ProgressEntryCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ProgressEntryPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a ProgressEntry.
     * @param {ProgressEntryDeleteArgs} args - Arguments to delete one ProgressEntry.
     * @example
     * // Delete one ProgressEntry
     * const ProgressEntry = await prisma.progressEntry.delete({
     *   where: {
     *     // ... filter to delete one ProgressEntry
     *   }
     * })
     * 
     */
    delete<T extends ProgressEntryDeleteArgs>(args: SelectSubset<T, ProgressEntryDeleteArgs<ExtArgs>>): Prisma__ProgressEntryClient<$Result.GetResult<Prisma.$ProgressEntryPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one ProgressEntry.
     * @param {ProgressEntryUpdateArgs} args - Arguments to update one ProgressEntry.
     * @example
     * // Update one ProgressEntry
     * const progressEntry = await prisma.progressEntry.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ProgressEntryUpdateArgs>(args: SelectSubset<T, ProgressEntryUpdateArgs<ExtArgs>>): Prisma__ProgressEntryClient<$Result.GetResult<Prisma.$ProgressEntryPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more ProgressEntries.
     * @param {ProgressEntryDeleteManyArgs} args - Arguments to filter ProgressEntries to delete.
     * @example
     * // Delete a few ProgressEntries
     * const { count } = await prisma.progressEntry.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ProgressEntryDeleteManyArgs>(args?: SelectSubset<T, ProgressEntryDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more ProgressEntries.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProgressEntryUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many ProgressEntries
     * const progressEntry = await prisma.progressEntry.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ProgressEntryUpdateManyArgs>(args: SelectSubset<T, ProgressEntryUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more ProgressEntries and returns the data updated in the database.
     * @param {ProgressEntryUpdateManyAndReturnArgs} args - Arguments to update many ProgressEntries.
     * @example
     * // Update many ProgressEntries
     * const progressEntry = await prisma.progressEntry.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more ProgressEntries and only return the `id`
     * const progressEntryWithIdOnly = await prisma.progressEntry.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends ProgressEntryUpdateManyAndReturnArgs>(args: SelectSubset<T, ProgressEntryUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ProgressEntryPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one ProgressEntry.
     * @param {ProgressEntryUpsertArgs} args - Arguments to update or create a ProgressEntry.
     * @example
     * // Update or create a ProgressEntry
     * const progressEntry = await prisma.progressEntry.upsert({
     *   create: {
     *     // ... data to create a ProgressEntry
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the ProgressEntry we want to update
     *   }
     * })
     */
    upsert<T extends ProgressEntryUpsertArgs>(args: SelectSubset<T, ProgressEntryUpsertArgs<ExtArgs>>): Prisma__ProgressEntryClient<$Result.GetResult<Prisma.$ProgressEntryPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of ProgressEntries.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProgressEntryCountArgs} args - Arguments to filter ProgressEntries to count.
     * @example
     * // Count the number of ProgressEntries
     * const count = await prisma.progressEntry.count({
     *   where: {
     *     // ... the filter for the ProgressEntries we want to count
     *   }
     * })
    **/
    count<T extends ProgressEntryCountArgs>(
      args?: Subset<T, ProgressEntryCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ProgressEntryCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a ProgressEntry.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProgressEntryAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ProgressEntryAggregateArgs>(args: Subset<T, ProgressEntryAggregateArgs>): Prisma.PrismaPromise<GetProgressEntryAggregateType<T>>

    /**
     * Group by ProgressEntry.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProgressEntryGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ProgressEntryGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ProgressEntryGroupByArgs['orderBy'] }
        : { orderBy?: ProgressEntryGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ProgressEntryGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetProgressEntryGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the ProgressEntry model
   */
  readonly fields: ProgressEntryFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for ProgressEntry.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ProgressEntryClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    workout<T extends WorkoutDefaultArgs<ExtArgs> = {}>(args?: Subset<T, WorkoutDefaultArgs<ExtArgs>>): Prisma__WorkoutClient<$Result.GetResult<Prisma.$WorkoutPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the ProgressEntry model
   */
  interface ProgressEntryFieldRefs {
    readonly id: FieldRef<"ProgressEntry", 'Int'>
    readonly user_id: FieldRef<"ProgressEntry", 'Int'>
    readonly workout_id: FieldRef<"ProgressEntry", 'Int'>
    readonly date_completed: FieldRef<"ProgressEntry", 'DateTime'>
    readonly notes: FieldRef<"ProgressEntry", 'String'>
    readonly createdAt: FieldRef<"ProgressEntry", 'DateTime'>
    readonly updatedAt: FieldRef<"ProgressEntry", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * ProgressEntry findUnique
   */
  export type ProgressEntryFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProgressEntry
     */
    select?: ProgressEntrySelect<ExtArgs> | null
    /**
     * Omit specific fields from the ProgressEntry
     */
    omit?: ProgressEntryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProgressEntryInclude<ExtArgs> | null
    /**
     * Filter, which ProgressEntry to fetch.
     */
    where: ProgressEntryWhereUniqueInput
  }

  /**
   * ProgressEntry findUniqueOrThrow
   */
  export type ProgressEntryFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProgressEntry
     */
    select?: ProgressEntrySelect<ExtArgs> | null
    /**
     * Omit specific fields from the ProgressEntry
     */
    omit?: ProgressEntryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProgressEntryInclude<ExtArgs> | null
    /**
     * Filter, which ProgressEntry to fetch.
     */
    where: ProgressEntryWhereUniqueInput
  }

  /**
   * ProgressEntry findFirst
   */
  export type ProgressEntryFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProgressEntry
     */
    select?: ProgressEntrySelect<ExtArgs> | null
    /**
     * Omit specific fields from the ProgressEntry
     */
    omit?: ProgressEntryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProgressEntryInclude<ExtArgs> | null
    /**
     * Filter, which ProgressEntry to fetch.
     */
    where?: ProgressEntryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ProgressEntries to fetch.
     */
    orderBy?: ProgressEntryOrderByWithRelationInput | ProgressEntryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ProgressEntries.
     */
    cursor?: ProgressEntryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ProgressEntries from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ProgressEntries.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ProgressEntries.
     */
    distinct?: ProgressEntryScalarFieldEnum | ProgressEntryScalarFieldEnum[]
  }

  /**
   * ProgressEntry findFirstOrThrow
   */
  export type ProgressEntryFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProgressEntry
     */
    select?: ProgressEntrySelect<ExtArgs> | null
    /**
     * Omit specific fields from the ProgressEntry
     */
    omit?: ProgressEntryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProgressEntryInclude<ExtArgs> | null
    /**
     * Filter, which ProgressEntry to fetch.
     */
    where?: ProgressEntryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ProgressEntries to fetch.
     */
    orderBy?: ProgressEntryOrderByWithRelationInput | ProgressEntryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ProgressEntries.
     */
    cursor?: ProgressEntryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ProgressEntries from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ProgressEntries.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ProgressEntries.
     */
    distinct?: ProgressEntryScalarFieldEnum | ProgressEntryScalarFieldEnum[]
  }

  /**
   * ProgressEntry findMany
   */
  export type ProgressEntryFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProgressEntry
     */
    select?: ProgressEntrySelect<ExtArgs> | null
    /**
     * Omit specific fields from the ProgressEntry
     */
    omit?: ProgressEntryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProgressEntryInclude<ExtArgs> | null
    /**
     * Filter, which ProgressEntries to fetch.
     */
    where?: ProgressEntryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ProgressEntries to fetch.
     */
    orderBy?: ProgressEntryOrderByWithRelationInput | ProgressEntryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing ProgressEntries.
     */
    cursor?: ProgressEntryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ProgressEntries from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ProgressEntries.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ProgressEntries.
     */
    distinct?: ProgressEntryScalarFieldEnum | ProgressEntryScalarFieldEnum[]
  }

  /**
   * ProgressEntry create
   */
  export type ProgressEntryCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProgressEntry
     */
    select?: ProgressEntrySelect<ExtArgs> | null
    /**
     * Omit specific fields from the ProgressEntry
     */
    omit?: ProgressEntryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProgressEntryInclude<ExtArgs> | null
    /**
     * The data needed to create a ProgressEntry.
     */
    data: XOR<ProgressEntryCreateInput, ProgressEntryUncheckedCreateInput>
  }

  /**
   * ProgressEntry createMany
   */
  export type ProgressEntryCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many ProgressEntries.
     */
    data: ProgressEntryCreateManyInput | ProgressEntryCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * ProgressEntry createManyAndReturn
   */
  export type ProgressEntryCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProgressEntry
     */
    select?: ProgressEntrySelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the ProgressEntry
     */
    omit?: ProgressEntryOmit<ExtArgs> | null
    /**
     * The data used to create many ProgressEntries.
     */
    data: ProgressEntryCreateManyInput | ProgressEntryCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProgressEntryIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * ProgressEntry update
   */
  export type ProgressEntryUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProgressEntry
     */
    select?: ProgressEntrySelect<ExtArgs> | null
    /**
     * Omit specific fields from the ProgressEntry
     */
    omit?: ProgressEntryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProgressEntryInclude<ExtArgs> | null
    /**
     * The data needed to update a ProgressEntry.
     */
    data: XOR<ProgressEntryUpdateInput, ProgressEntryUncheckedUpdateInput>
    /**
     * Choose, which ProgressEntry to update.
     */
    where: ProgressEntryWhereUniqueInput
  }

  /**
   * ProgressEntry updateMany
   */
  export type ProgressEntryUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update ProgressEntries.
     */
    data: XOR<ProgressEntryUpdateManyMutationInput, ProgressEntryUncheckedUpdateManyInput>
    /**
     * Filter which ProgressEntries to update
     */
    where?: ProgressEntryWhereInput
    /**
     * Limit how many ProgressEntries to update.
     */
    limit?: number
  }

  /**
   * ProgressEntry updateManyAndReturn
   */
  export type ProgressEntryUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProgressEntry
     */
    select?: ProgressEntrySelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the ProgressEntry
     */
    omit?: ProgressEntryOmit<ExtArgs> | null
    /**
     * The data used to update ProgressEntries.
     */
    data: XOR<ProgressEntryUpdateManyMutationInput, ProgressEntryUncheckedUpdateManyInput>
    /**
     * Filter which ProgressEntries to update
     */
    where?: ProgressEntryWhereInput
    /**
     * Limit how many ProgressEntries to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProgressEntryIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * ProgressEntry upsert
   */
  export type ProgressEntryUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProgressEntry
     */
    select?: ProgressEntrySelect<ExtArgs> | null
    /**
     * Omit specific fields from the ProgressEntry
     */
    omit?: ProgressEntryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProgressEntryInclude<ExtArgs> | null
    /**
     * The filter to search for the ProgressEntry to update in case it exists.
     */
    where: ProgressEntryWhereUniqueInput
    /**
     * In case the ProgressEntry found by the `where` argument doesn't exist, create a new ProgressEntry with this data.
     */
    create: XOR<ProgressEntryCreateInput, ProgressEntryUncheckedCreateInput>
    /**
     * In case the ProgressEntry was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ProgressEntryUpdateInput, ProgressEntryUncheckedUpdateInput>
  }

  /**
   * ProgressEntry delete
   */
  export type ProgressEntryDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProgressEntry
     */
    select?: ProgressEntrySelect<ExtArgs> | null
    /**
     * Omit specific fields from the ProgressEntry
     */
    omit?: ProgressEntryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProgressEntryInclude<ExtArgs> | null
    /**
     * Filter which ProgressEntry to delete.
     */
    where: ProgressEntryWhereUniqueInput
  }

  /**
   * ProgressEntry deleteMany
   */
  export type ProgressEntryDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ProgressEntries to delete
     */
    where?: ProgressEntryWhereInput
    /**
     * Limit how many ProgressEntries to delete.
     */
    limit?: number
  }

  /**
   * ProgressEntry without action
   */
  export type ProgressEntryDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProgressEntry
     */
    select?: ProgressEntrySelect<ExtArgs> | null
    /**
     * Omit specific fields from the ProgressEntry
     */
    omit?: ProgressEntryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProgressEntryInclude<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const UserScalarFieldEnum: {
    id: 'id',
    name: 'name',
    email: 'email',
    password_hash: 'password_hash',
    role: 'role',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type UserScalarFieldEnum = (typeof UserScalarFieldEnum)[keyof typeof UserScalarFieldEnum]


  export const WorkoutScalarFieldEnum: {
    id: 'id',
    title: 'title',
    description: 'description',
    category: 'category',
    difficulty: 'difficulty',
    duration_minutes: 'duration_minutes',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type WorkoutScalarFieldEnum = (typeof WorkoutScalarFieldEnum)[keyof typeof WorkoutScalarFieldEnum]


  export const WorkoutPlanScalarFieldEnum: {
    id: 'id',
    user_id: 'user_id',
    title: 'title',
    goal: 'goal',
    duration_weeks: 'duration_weeks',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type WorkoutPlanScalarFieldEnum = (typeof WorkoutPlanScalarFieldEnum)[keyof typeof WorkoutPlanScalarFieldEnum]


  export const PlanWorkoutScalarFieldEnum: {
    plan_id: 'plan_id',
    workout_id: 'workout_id',
    day_number: 'day_number'
  };

  export type PlanWorkoutScalarFieldEnum = (typeof PlanWorkoutScalarFieldEnum)[keyof typeof PlanWorkoutScalarFieldEnum]


  export const ProgressEntryScalarFieldEnum: {
    id: 'id',
    user_id: 'user_id',
    workout_id: 'workout_id',
    date_completed: 'date_completed',
    notes: 'notes',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type ProgressEntryScalarFieldEnum = (typeof ProgressEntryScalarFieldEnum)[keyof typeof ProgressEntryScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const QueryMode: {
    default: 'default',
    insensitive: 'insensitive'
  };

  export type QueryMode = (typeof QueryMode)[keyof typeof QueryMode]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'Int[]'
   */
  export type ListIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int[]'>
    


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'String[]'
   */
  export type ListStringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String[]'>
    


  /**
   * Reference to a field of type 'Role'
   */
  export type EnumRoleFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Role'>
    


  /**
   * Reference to a field of type 'Role[]'
   */
  export type ListEnumRoleFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Role[]'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'DateTime[]'
   */
  export type ListDateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime[]'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    


  /**
   * Reference to a field of type 'Float[]'
   */
  export type ListFloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float[]'>
    
  /**
   * Deep Input Types
   */


  export type UserWhereInput = {
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    id?: IntFilter<"User"> | number
    name?: StringFilter<"User"> | string
    email?: StringFilter<"User"> | string
    password_hash?: StringFilter<"User"> | string
    role?: EnumRoleFilter<"User"> | $Enums.Role
    createdAt?: DateTimeFilter<"User"> | Date | string
    updatedAt?: DateTimeFilter<"User"> | Date | string
    workoutPlans?: WorkoutPlanListRelationFilter
    progressEntries?: ProgressEntryListRelationFilter
  }

  export type UserOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    password_hash?: SortOrder
    role?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    workoutPlans?: WorkoutPlanOrderByRelationAggregateInput
    progressEntries?: ProgressEntryOrderByRelationAggregateInput
  }

  export type UserWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    email?: string
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    name?: StringFilter<"User"> | string
    password_hash?: StringFilter<"User"> | string
    role?: EnumRoleFilter<"User"> | $Enums.Role
    createdAt?: DateTimeFilter<"User"> | Date | string
    updatedAt?: DateTimeFilter<"User"> | Date | string
    workoutPlans?: WorkoutPlanListRelationFilter
    progressEntries?: ProgressEntryListRelationFilter
  }, "id" | "email">

  export type UserOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    password_hash?: SortOrder
    role?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: UserCountOrderByAggregateInput
    _avg?: UserAvgOrderByAggregateInput
    _max?: UserMaxOrderByAggregateInput
    _min?: UserMinOrderByAggregateInput
    _sum?: UserSumOrderByAggregateInput
  }

  export type UserScalarWhereWithAggregatesInput = {
    AND?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    OR?: UserScalarWhereWithAggregatesInput[]
    NOT?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"User"> | number
    name?: StringWithAggregatesFilter<"User"> | string
    email?: StringWithAggregatesFilter<"User"> | string
    password_hash?: StringWithAggregatesFilter<"User"> | string
    role?: EnumRoleWithAggregatesFilter<"User"> | $Enums.Role
    createdAt?: DateTimeWithAggregatesFilter<"User"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"User"> | Date | string
  }

  export type WorkoutWhereInput = {
    AND?: WorkoutWhereInput | WorkoutWhereInput[]
    OR?: WorkoutWhereInput[]
    NOT?: WorkoutWhereInput | WorkoutWhereInput[]
    id?: IntFilter<"Workout"> | number
    title?: StringFilter<"Workout"> | string
    description?: StringFilter<"Workout"> | string
    category?: StringFilter<"Workout"> | string
    difficulty?: StringFilter<"Workout"> | string
    duration_minutes?: IntFilter<"Workout"> | number
    createdAt?: DateTimeFilter<"Workout"> | Date | string
    updatedAt?: DateTimeFilter<"Workout"> | Date | string
    planWorkouts?: PlanWorkoutListRelationFilter
    progressEntries?: ProgressEntryListRelationFilter
  }

  export type WorkoutOrderByWithRelationInput = {
    id?: SortOrder
    title?: SortOrder
    description?: SortOrder
    category?: SortOrder
    difficulty?: SortOrder
    duration_minutes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    planWorkouts?: PlanWorkoutOrderByRelationAggregateInput
    progressEntries?: ProgressEntryOrderByRelationAggregateInput
  }

  export type WorkoutWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: WorkoutWhereInput | WorkoutWhereInput[]
    OR?: WorkoutWhereInput[]
    NOT?: WorkoutWhereInput | WorkoutWhereInput[]
    title?: StringFilter<"Workout"> | string
    description?: StringFilter<"Workout"> | string
    category?: StringFilter<"Workout"> | string
    difficulty?: StringFilter<"Workout"> | string
    duration_minutes?: IntFilter<"Workout"> | number
    createdAt?: DateTimeFilter<"Workout"> | Date | string
    updatedAt?: DateTimeFilter<"Workout"> | Date | string
    planWorkouts?: PlanWorkoutListRelationFilter
    progressEntries?: ProgressEntryListRelationFilter
  }, "id">

  export type WorkoutOrderByWithAggregationInput = {
    id?: SortOrder
    title?: SortOrder
    description?: SortOrder
    category?: SortOrder
    difficulty?: SortOrder
    duration_minutes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: WorkoutCountOrderByAggregateInput
    _avg?: WorkoutAvgOrderByAggregateInput
    _max?: WorkoutMaxOrderByAggregateInput
    _min?: WorkoutMinOrderByAggregateInput
    _sum?: WorkoutSumOrderByAggregateInput
  }

  export type WorkoutScalarWhereWithAggregatesInput = {
    AND?: WorkoutScalarWhereWithAggregatesInput | WorkoutScalarWhereWithAggregatesInput[]
    OR?: WorkoutScalarWhereWithAggregatesInput[]
    NOT?: WorkoutScalarWhereWithAggregatesInput | WorkoutScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"Workout"> | number
    title?: StringWithAggregatesFilter<"Workout"> | string
    description?: StringWithAggregatesFilter<"Workout"> | string
    category?: StringWithAggregatesFilter<"Workout"> | string
    difficulty?: StringWithAggregatesFilter<"Workout"> | string
    duration_minutes?: IntWithAggregatesFilter<"Workout"> | number
    createdAt?: DateTimeWithAggregatesFilter<"Workout"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Workout"> | Date | string
  }

  export type WorkoutPlanWhereInput = {
    AND?: WorkoutPlanWhereInput | WorkoutPlanWhereInput[]
    OR?: WorkoutPlanWhereInput[]
    NOT?: WorkoutPlanWhereInput | WorkoutPlanWhereInput[]
    id?: IntFilter<"WorkoutPlan"> | number
    user_id?: IntFilter<"WorkoutPlan"> | number
    title?: StringFilter<"WorkoutPlan"> | string
    goal?: StringFilter<"WorkoutPlan"> | string
    duration_weeks?: IntFilter<"WorkoutPlan"> | number
    createdAt?: DateTimeFilter<"WorkoutPlan"> | Date | string
    updatedAt?: DateTimeFilter<"WorkoutPlan"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    planWorkouts?: PlanWorkoutListRelationFilter
  }

  export type WorkoutPlanOrderByWithRelationInput = {
    id?: SortOrder
    user_id?: SortOrder
    title?: SortOrder
    goal?: SortOrder
    duration_weeks?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    user?: UserOrderByWithRelationInput
    planWorkouts?: PlanWorkoutOrderByRelationAggregateInput
  }

  export type WorkoutPlanWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: WorkoutPlanWhereInput | WorkoutPlanWhereInput[]
    OR?: WorkoutPlanWhereInput[]
    NOT?: WorkoutPlanWhereInput | WorkoutPlanWhereInput[]
    user_id?: IntFilter<"WorkoutPlan"> | number
    title?: StringFilter<"WorkoutPlan"> | string
    goal?: StringFilter<"WorkoutPlan"> | string
    duration_weeks?: IntFilter<"WorkoutPlan"> | number
    createdAt?: DateTimeFilter<"WorkoutPlan"> | Date | string
    updatedAt?: DateTimeFilter<"WorkoutPlan"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    planWorkouts?: PlanWorkoutListRelationFilter
  }, "id">

  export type WorkoutPlanOrderByWithAggregationInput = {
    id?: SortOrder
    user_id?: SortOrder
    title?: SortOrder
    goal?: SortOrder
    duration_weeks?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: WorkoutPlanCountOrderByAggregateInput
    _avg?: WorkoutPlanAvgOrderByAggregateInput
    _max?: WorkoutPlanMaxOrderByAggregateInput
    _min?: WorkoutPlanMinOrderByAggregateInput
    _sum?: WorkoutPlanSumOrderByAggregateInput
  }

  export type WorkoutPlanScalarWhereWithAggregatesInput = {
    AND?: WorkoutPlanScalarWhereWithAggregatesInput | WorkoutPlanScalarWhereWithAggregatesInput[]
    OR?: WorkoutPlanScalarWhereWithAggregatesInput[]
    NOT?: WorkoutPlanScalarWhereWithAggregatesInput | WorkoutPlanScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"WorkoutPlan"> | number
    user_id?: IntWithAggregatesFilter<"WorkoutPlan"> | number
    title?: StringWithAggregatesFilter<"WorkoutPlan"> | string
    goal?: StringWithAggregatesFilter<"WorkoutPlan"> | string
    duration_weeks?: IntWithAggregatesFilter<"WorkoutPlan"> | number
    createdAt?: DateTimeWithAggregatesFilter<"WorkoutPlan"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"WorkoutPlan"> | Date | string
  }

  export type PlanWorkoutWhereInput = {
    AND?: PlanWorkoutWhereInput | PlanWorkoutWhereInput[]
    OR?: PlanWorkoutWhereInput[]
    NOT?: PlanWorkoutWhereInput | PlanWorkoutWhereInput[]
    plan_id?: IntFilter<"PlanWorkout"> | number
    workout_id?: IntFilter<"PlanWorkout"> | number
    day_number?: IntFilter<"PlanWorkout"> | number
    plan?: XOR<WorkoutPlanScalarRelationFilter, WorkoutPlanWhereInput>
    workout?: XOR<WorkoutScalarRelationFilter, WorkoutWhereInput>
  }

  export type PlanWorkoutOrderByWithRelationInput = {
    plan_id?: SortOrder
    workout_id?: SortOrder
    day_number?: SortOrder
    plan?: WorkoutPlanOrderByWithRelationInput
    workout?: WorkoutOrderByWithRelationInput
  }

  export type PlanWorkoutWhereUniqueInput = Prisma.AtLeast<{
    plan_id_workout_id?: PlanWorkoutPlan_idWorkout_idCompoundUniqueInput
    AND?: PlanWorkoutWhereInput | PlanWorkoutWhereInput[]
    OR?: PlanWorkoutWhereInput[]
    NOT?: PlanWorkoutWhereInput | PlanWorkoutWhereInput[]
    plan_id?: IntFilter<"PlanWorkout"> | number
    workout_id?: IntFilter<"PlanWorkout"> | number
    day_number?: IntFilter<"PlanWorkout"> | number
    plan?: XOR<WorkoutPlanScalarRelationFilter, WorkoutPlanWhereInput>
    workout?: XOR<WorkoutScalarRelationFilter, WorkoutWhereInput>
  }, "plan_id_workout_id">

  export type PlanWorkoutOrderByWithAggregationInput = {
    plan_id?: SortOrder
    workout_id?: SortOrder
    day_number?: SortOrder
    _count?: PlanWorkoutCountOrderByAggregateInput
    _avg?: PlanWorkoutAvgOrderByAggregateInput
    _max?: PlanWorkoutMaxOrderByAggregateInput
    _min?: PlanWorkoutMinOrderByAggregateInput
    _sum?: PlanWorkoutSumOrderByAggregateInput
  }

  export type PlanWorkoutScalarWhereWithAggregatesInput = {
    AND?: PlanWorkoutScalarWhereWithAggregatesInput | PlanWorkoutScalarWhereWithAggregatesInput[]
    OR?: PlanWorkoutScalarWhereWithAggregatesInput[]
    NOT?: PlanWorkoutScalarWhereWithAggregatesInput | PlanWorkoutScalarWhereWithAggregatesInput[]
    plan_id?: IntWithAggregatesFilter<"PlanWorkout"> | number
    workout_id?: IntWithAggregatesFilter<"PlanWorkout"> | number
    day_number?: IntWithAggregatesFilter<"PlanWorkout"> | number
  }

  export type ProgressEntryWhereInput = {
    AND?: ProgressEntryWhereInput | ProgressEntryWhereInput[]
    OR?: ProgressEntryWhereInput[]
    NOT?: ProgressEntryWhereInput | ProgressEntryWhereInput[]
    id?: IntFilter<"ProgressEntry"> | number
    user_id?: IntFilter<"ProgressEntry"> | number
    workout_id?: IntFilter<"ProgressEntry"> | number
    date_completed?: DateTimeFilter<"ProgressEntry"> | Date | string
    notes?: StringNullableFilter<"ProgressEntry"> | string | null
    createdAt?: DateTimeFilter<"ProgressEntry"> | Date | string
    updatedAt?: DateTimeFilter<"ProgressEntry"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    workout?: XOR<WorkoutScalarRelationFilter, WorkoutWhereInput>
  }

  export type ProgressEntryOrderByWithRelationInput = {
    id?: SortOrder
    user_id?: SortOrder
    workout_id?: SortOrder
    date_completed?: SortOrder
    notes?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    user?: UserOrderByWithRelationInput
    workout?: WorkoutOrderByWithRelationInput
  }

  export type ProgressEntryWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: ProgressEntryWhereInput | ProgressEntryWhereInput[]
    OR?: ProgressEntryWhereInput[]
    NOT?: ProgressEntryWhereInput | ProgressEntryWhereInput[]
    user_id?: IntFilter<"ProgressEntry"> | number
    workout_id?: IntFilter<"ProgressEntry"> | number
    date_completed?: DateTimeFilter<"ProgressEntry"> | Date | string
    notes?: StringNullableFilter<"ProgressEntry"> | string | null
    createdAt?: DateTimeFilter<"ProgressEntry"> | Date | string
    updatedAt?: DateTimeFilter<"ProgressEntry"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    workout?: XOR<WorkoutScalarRelationFilter, WorkoutWhereInput>
  }, "id">

  export type ProgressEntryOrderByWithAggregationInput = {
    id?: SortOrder
    user_id?: SortOrder
    workout_id?: SortOrder
    date_completed?: SortOrder
    notes?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: ProgressEntryCountOrderByAggregateInput
    _avg?: ProgressEntryAvgOrderByAggregateInput
    _max?: ProgressEntryMaxOrderByAggregateInput
    _min?: ProgressEntryMinOrderByAggregateInput
    _sum?: ProgressEntrySumOrderByAggregateInput
  }

  export type ProgressEntryScalarWhereWithAggregatesInput = {
    AND?: ProgressEntryScalarWhereWithAggregatesInput | ProgressEntryScalarWhereWithAggregatesInput[]
    OR?: ProgressEntryScalarWhereWithAggregatesInput[]
    NOT?: ProgressEntryScalarWhereWithAggregatesInput | ProgressEntryScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"ProgressEntry"> | number
    user_id?: IntWithAggregatesFilter<"ProgressEntry"> | number
    workout_id?: IntWithAggregatesFilter<"ProgressEntry"> | number
    date_completed?: DateTimeWithAggregatesFilter<"ProgressEntry"> | Date | string
    notes?: StringNullableWithAggregatesFilter<"ProgressEntry"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"ProgressEntry"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"ProgressEntry"> | Date | string
  }

  export type UserCreateInput = {
    name: string
    email: string
    password_hash: string
    role?: $Enums.Role
    createdAt?: Date | string
    updatedAt?: Date | string
    workoutPlans?: WorkoutPlanCreateNestedManyWithoutUserInput
    progressEntries?: ProgressEntryCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateInput = {
    id?: number
    name: string
    email: string
    password_hash: string
    role?: $Enums.Role
    createdAt?: Date | string
    updatedAt?: Date | string
    workoutPlans?: WorkoutPlanUncheckedCreateNestedManyWithoutUserInput
    progressEntries?: ProgressEntryUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    workoutPlans?: WorkoutPlanUpdateManyWithoutUserNestedInput
    progressEntries?: ProgressEntryUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    workoutPlans?: WorkoutPlanUncheckedUpdateManyWithoutUserNestedInput
    progressEntries?: ProgressEntryUncheckedUpdateManyWithoutUserNestedInput
  }

  export type UserCreateManyInput = {
    id?: number
    name: string
    email: string
    password_hash: string
    role?: $Enums.Role
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type UserUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type WorkoutCreateInput = {
    title: string
    description: string
    category: string
    difficulty: string
    duration_minutes: number
    createdAt?: Date | string
    updatedAt?: Date | string
    planWorkouts?: PlanWorkoutCreateNestedManyWithoutWorkoutInput
    progressEntries?: ProgressEntryCreateNestedManyWithoutWorkoutInput
  }

  export type WorkoutUncheckedCreateInput = {
    id?: number
    title: string
    description: string
    category: string
    difficulty: string
    duration_minutes: number
    createdAt?: Date | string
    updatedAt?: Date | string
    planWorkouts?: PlanWorkoutUncheckedCreateNestedManyWithoutWorkoutInput
    progressEntries?: ProgressEntryUncheckedCreateNestedManyWithoutWorkoutInput
  }

  export type WorkoutUpdateInput = {
    title?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    difficulty?: StringFieldUpdateOperationsInput | string
    duration_minutes?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    planWorkouts?: PlanWorkoutUpdateManyWithoutWorkoutNestedInput
    progressEntries?: ProgressEntryUpdateManyWithoutWorkoutNestedInput
  }

  export type WorkoutUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    title?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    difficulty?: StringFieldUpdateOperationsInput | string
    duration_minutes?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    planWorkouts?: PlanWorkoutUncheckedUpdateManyWithoutWorkoutNestedInput
    progressEntries?: ProgressEntryUncheckedUpdateManyWithoutWorkoutNestedInput
  }

  export type WorkoutCreateManyInput = {
    id?: number
    title: string
    description: string
    category: string
    difficulty: string
    duration_minutes: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type WorkoutUpdateManyMutationInput = {
    title?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    difficulty?: StringFieldUpdateOperationsInput | string
    duration_minutes?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type WorkoutUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    title?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    difficulty?: StringFieldUpdateOperationsInput | string
    duration_minutes?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type WorkoutPlanCreateInput = {
    title: string
    goal: string
    duration_weeks: number
    createdAt?: Date | string
    updatedAt?: Date | string
    user: UserCreateNestedOneWithoutWorkoutPlansInput
    planWorkouts?: PlanWorkoutCreateNestedManyWithoutPlanInput
  }

  export type WorkoutPlanUncheckedCreateInput = {
    id?: number
    user_id: number
    title: string
    goal: string
    duration_weeks: number
    createdAt?: Date | string
    updatedAt?: Date | string
    planWorkouts?: PlanWorkoutUncheckedCreateNestedManyWithoutPlanInput
  }

  export type WorkoutPlanUpdateInput = {
    title?: StringFieldUpdateOperationsInput | string
    goal?: StringFieldUpdateOperationsInput | string
    duration_weeks?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutWorkoutPlansNestedInput
    planWorkouts?: PlanWorkoutUpdateManyWithoutPlanNestedInput
  }

  export type WorkoutPlanUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    user_id?: IntFieldUpdateOperationsInput | number
    title?: StringFieldUpdateOperationsInput | string
    goal?: StringFieldUpdateOperationsInput | string
    duration_weeks?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    planWorkouts?: PlanWorkoutUncheckedUpdateManyWithoutPlanNestedInput
  }

  export type WorkoutPlanCreateManyInput = {
    id?: number
    user_id: number
    title: string
    goal: string
    duration_weeks: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type WorkoutPlanUpdateManyMutationInput = {
    title?: StringFieldUpdateOperationsInput | string
    goal?: StringFieldUpdateOperationsInput | string
    duration_weeks?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type WorkoutPlanUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    user_id?: IntFieldUpdateOperationsInput | number
    title?: StringFieldUpdateOperationsInput | string
    goal?: StringFieldUpdateOperationsInput | string
    duration_weeks?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PlanWorkoutCreateInput = {
    day_number: number
    plan: WorkoutPlanCreateNestedOneWithoutPlanWorkoutsInput
    workout: WorkoutCreateNestedOneWithoutPlanWorkoutsInput
  }

  export type PlanWorkoutUncheckedCreateInput = {
    plan_id: number
    workout_id: number
    day_number: number
  }

  export type PlanWorkoutUpdateInput = {
    day_number?: IntFieldUpdateOperationsInput | number
    plan?: WorkoutPlanUpdateOneRequiredWithoutPlanWorkoutsNestedInput
    workout?: WorkoutUpdateOneRequiredWithoutPlanWorkoutsNestedInput
  }

  export type PlanWorkoutUncheckedUpdateInput = {
    plan_id?: IntFieldUpdateOperationsInput | number
    workout_id?: IntFieldUpdateOperationsInput | number
    day_number?: IntFieldUpdateOperationsInput | number
  }

  export type PlanWorkoutCreateManyInput = {
    plan_id: number
    workout_id: number
    day_number: number
  }

  export type PlanWorkoutUpdateManyMutationInput = {
    day_number?: IntFieldUpdateOperationsInput | number
  }

  export type PlanWorkoutUncheckedUpdateManyInput = {
    plan_id?: IntFieldUpdateOperationsInput | number
    workout_id?: IntFieldUpdateOperationsInput | number
    day_number?: IntFieldUpdateOperationsInput | number
  }

  export type ProgressEntryCreateInput = {
    date_completed: Date | string
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    user: UserCreateNestedOneWithoutProgressEntriesInput
    workout: WorkoutCreateNestedOneWithoutProgressEntriesInput
  }

  export type ProgressEntryUncheckedCreateInput = {
    id?: number
    user_id: number
    workout_id: number
    date_completed: Date | string
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type ProgressEntryUpdateInput = {
    date_completed?: DateTimeFieldUpdateOperationsInput | Date | string
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutProgressEntriesNestedInput
    workout?: WorkoutUpdateOneRequiredWithoutProgressEntriesNestedInput
  }

  export type ProgressEntryUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    user_id?: IntFieldUpdateOperationsInput | number
    workout_id?: IntFieldUpdateOperationsInput | number
    date_completed?: DateTimeFieldUpdateOperationsInput | Date | string
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ProgressEntryCreateManyInput = {
    id?: number
    user_id: number
    workout_id: number
    date_completed: Date | string
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type ProgressEntryUpdateManyMutationInput = {
    date_completed?: DateTimeFieldUpdateOperationsInput | Date | string
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ProgressEntryUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    user_id?: IntFieldUpdateOperationsInput | number
    workout_id?: IntFieldUpdateOperationsInput | number
    date_completed?: DateTimeFieldUpdateOperationsInput | Date | string
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type EnumRoleFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    notIn?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    not?: NestedEnumRoleFilter<$PrismaModel> | $Enums.Role
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type WorkoutPlanListRelationFilter = {
    every?: WorkoutPlanWhereInput
    some?: WorkoutPlanWhereInput
    none?: WorkoutPlanWhereInput
  }

  export type ProgressEntryListRelationFilter = {
    every?: ProgressEntryWhereInput
    some?: ProgressEntryWhereInput
    none?: ProgressEntryWhereInput
  }

  export type WorkoutPlanOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type ProgressEntryOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type UserCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    password_hash?: SortOrder
    role?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type UserAvgOrderByAggregateInput = {
    id?: SortOrder
  }

  export type UserMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    password_hash?: SortOrder
    role?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type UserMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    password_hash?: SortOrder
    role?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type UserSumOrderByAggregateInput = {
    id?: SortOrder
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type EnumRoleWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    notIn?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    not?: NestedEnumRoleWithAggregatesFilter<$PrismaModel> | $Enums.Role
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumRoleFilter<$PrismaModel>
    _max?: NestedEnumRoleFilter<$PrismaModel>
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type PlanWorkoutListRelationFilter = {
    every?: PlanWorkoutWhereInput
    some?: PlanWorkoutWhereInput
    none?: PlanWorkoutWhereInput
  }

  export type PlanWorkoutOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type WorkoutCountOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    description?: SortOrder
    category?: SortOrder
    difficulty?: SortOrder
    duration_minutes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type WorkoutAvgOrderByAggregateInput = {
    id?: SortOrder
    duration_minutes?: SortOrder
  }

  export type WorkoutMaxOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    description?: SortOrder
    category?: SortOrder
    difficulty?: SortOrder
    duration_minutes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type WorkoutMinOrderByAggregateInput = {
    id?: SortOrder
    title?: SortOrder
    description?: SortOrder
    category?: SortOrder
    difficulty?: SortOrder
    duration_minutes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type WorkoutSumOrderByAggregateInput = {
    id?: SortOrder
    duration_minutes?: SortOrder
  }

  export type UserScalarRelationFilter = {
    is?: UserWhereInput
    isNot?: UserWhereInput
  }

  export type WorkoutPlanCountOrderByAggregateInput = {
    id?: SortOrder
    user_id?: SortOrder
    title?: SortOrder
    goal?: SortOrder
    duration_weeks?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type WorkoutPlanAvgOrderByAggregateInput = {
    id?: SortOrder
    user_id?: SortOrder
    duration_weeks?: SortOrder
  }

  export type WorkoutPlanMaxOrderByAggregateInput = {
    id?: SortOrder
    user_id?: SortOrder
    title?: SortOrder
    goal?: SortOrder
    duration_weeks?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type WorkoutPlanMinOrderByAggregateInput = {
    id?: SortOrder
    user_id?: SortOrder
    title?: SortOrder
    goal?: SortOrder
    duration_weeks?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type WorkoutPlanSumOrderByAggregateInput = {
    id?: SortOrder
    user_id?: SortOrder
    duration_weeks?: SortOrder
  }

  export type WorkoutPlanScalarRelationFilter = {
    is?: WorkoutPlanWhereInput
    isNot?: WorkoutPlanWhereInput
  }

  export type WorkoutScalarRelationFilter = {
    is?: WorkoutWhereInput
    isNot?: WorkoutWhereInput
  }

  export type PlanWorkoutPlan_idWorkout_idCompoundUniqueInput = {
    plan_id: number
    workout_id: number
  }

  export type PlanWorkoutCountOrderByAggregateInput = {
    plan_id?: SortOrder
    workout_id?: SortOrder
    day_number?: SortOrder
  }

  export type PlanWorkoutAvgOrderByAggregateInput = {
    plan_id?: SortOrder
    workout_id?: SortOrder
    day_number?: SortOrder
  }

  export type PlanWorkoutMaxOrderByAggregateInput = {
    plan_id?: SortOrder
    workout_id?: SortOrder
    day_number?: SortOrder
  }

  export type PlanWorkoutMinOrderByAggregateInput = {
    plan_id?: SortOrder
    workout_id?: SortOrder
    day_number?: SortOrder
  }

  export type PlanWorkoutSumOrderByAggregateInput = {
    plan_id?: SortOrder
    workout_id?: SortOrder
    day_number?: SortOrder
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type ProgressEntryCountOrderByAggregateInput = {
    id?: SortOrder
    user_id?: SortOrder
    workout_id?: SortOrder
    date_completed?: SortOrder
    notes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type ProgressEntryAvgOrderByAggregateInput = {
    id?: SortOrder
    user_id?: SortOrder
    workout_id?: SortOrder
  }

  export type ProgressEntryMaxOrderByAggregateInput = {
    id?: SortOrder
    user_id?: SortOrder
    workout_id?: SortOrder
    date_completed?: SortOrder
    notes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type ProgressEntryMinOrderByAggregateInput = {
    id?: SortOrder
    user_id?: SortOrder
    workout_id?: SortOrder
    date_completed?: SortOrder
    notes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type ProgressEntrySumOrderByAggregateInput = {
    id?: SortOrder
    user_id?: SortOrder
    workout_id?: SortOrder
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type WorkoutPlanCreateNestedManyWithoutUserInput = {
    create?: XOR<WorkoutPlanCreateWithoutUserInput, WorkoutPlanUncheckedCreateWithoutUserInput> | WorkoutPlanCreateWithoutUserInput[] | WorkoutPlanUncheckedCreateWithoutUserInput[]
    connectOrCreate?: WorkoutPlanCreateOrConnectWithoutUserInput | WorkoutPlanCreateOrConnectWithoutUserInput[]
    createMany?: WorkoutPlanCreateManyUserInputEnvelope
    connect?: WorkoutPlanWhereUniqueInput | WorkoutPlanWhereUniqueInput[]
  }

  export type ProgressEntryCreateNestedManyWithoutUserInput = {
    create?: XOR<ProgressEntryCreateWithoutUserInput, ProgressEntryUncheckedCreateWithoutUserInput> | ProgressEntryCreateWithoutUserInput[] | ProgressEntryUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ProgressEntryCreateOrConnectWithoutUserInput | ProgressEntryCreateOrConnectWithoutUserInput[]
    createMany?: ProgressEntryCreateManyUserInputEnvelope
    connect?: ProgressEntryWhereUniqueInput | ProgressEntryWhereUniqueInput[]
  }

  export type WorkoutPlanUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<WorkoutPlanCreateWithoutUserInput, WorkoutPlanUncheckedCreateWithoutUserInput> | WorkoutPlanCreateWithoutUserInput[] | WorkoutPlanUncheckedCreateWithoutUserInput[]
    connectOrCreate?: WorkoutPlanCreateOrConnectWithoutUserInput | WorkoutPlanCreateOrConnectWithoutUserInput[]
    createMany?: WorkoutPlanCreateManyUserInputEnvelope
    connect?: WorkoutPlanWhereUniqueInput | WorkoutPlanWhereUniqueInput[]
  }

  export type ProgressEntryUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<ProgressEntryCreateWithoutUserInput, ProgressEntryUncheckedCreateWithoutUserInput> | ProgressEntryCreateWithoutUserInput[] | ProgressEntryUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ProgressEntryCreateOrConnectWithoutUserInput | ProgressEntryCreateOrConnectWithoutUserInput[]
    createMany?: ProgressEntryCreateManyUserInputEnvelope
    connect?: ProgressEntryWhereUniqueInput | ProgressEntryWhereUniqueInput[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type EnumRoleFieldUpdateOperationsInput = {
    set?: $Enums.Role
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type WorkoutPlanUpdateManyWithoutUserNestedInput = {
    create?: XOR<WorkoutPlanCreateWithoutUserInput, WorkoutPlanUncheckedCreateWithoutUserInput> | WorkoutPlanCreateWithoutUserInput[] | WorkoutPlanUncheckedCreateWithoutUserInput[]
    connectOrCreate?: WorkoutPlanCreateOrConnectWithoutUserInput | WorkoutPlanCreateOrConnectWithoutUserInput[]
    upsert?: WorkoutPlanUpsertWithWhereUniqueWithoutUserInput | WorkoutPlanUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: WorkoutPlanCreateManyUserInputEnvelope
    set?: WorkoutPlanWhereUniqueInput | WorkoutPlanWhereUniqueInput[]
    disconnect?: WorkoutPlanWhereUniqueInput | WorkoutPlanWhereUniqueInput[]
    delete?: WorkoutPlanWhereUniqueInput | WorkoutPlanWhereUniqueInput[]
    connect?: WorkoutPlanWhereUniqueInput | WorkoutPlanWhereUniqueInput[]
    update?: WorkoutPlanUpdateWithWhereUniqueWithoutUserInput | WorkoutPlanUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: WorkoutPlanUpdateManyWithWhereWithoutUserInput | WorkoutPlanUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: WorkoutPlanScalarWhereInput | WorkoutPlanScalarWhereInput[]
  }

  export type ProgressEntryUpdateManyWithoutUserNestedInput = {
    create?: XOR<ProgressEntryCreateWithoutUserInput, ProgressEntryUncheckedCreateWithoutUserInput> | ProgressEntryCreateWithoutUserInput[] | ProgressEntryUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ProgressEntryCreateOrConnectWithoutUserInput | ProgressEntryCreateOrConnectWithoutUserInput[]
    upsert?: ProgressEntryUpsertWithWhereUniqueWithoutUserInput | ProgressEntryUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: ProgressEntryCreateManyUserInputEnvelope
    set?: ProgressEntryWhereUniqueInput | ProgressEntryWhereUniqueInput[]
    disconnect?: ProgressEntryWhereUniqueInput | ProgressEntryWhereUniqueInput[]
    delete?: ProgressEntryWhereUniqueInput | ProgressEntryWhereUniqueInput[]
    connect?: ProgressEntryWhereUniqueInput | ProgressEntryWhereUniqueInput[]
    update?: ProgressEntryUpdateWithWhereUniqueWithoutUserInput | ProgressEntryUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: ProgressEntryUpdateManyWithWhereWithoutUserInput | ProgressEntryUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: ProgressEntryScalarWhereInput | ProgressEntryScalarWhereInput[]
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type WorkoutPlanUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<WorkoutPlanCreateWithoutUserInput, WorkoutPlanUncheckedCreateWithoutUserInput> | WorkoutPlanCreateWithoutUserInput[] | WorkoutPlanUncheckedCreateWithoutUserInput[]
    connectOrCreate?: WorkoutPlanCreateOrConnectWithoutUserInput | WorkoutPlanCreateOrConnectWithoutUserInput[]
    upsert?: WorkoutPlanUpsertWithWhereUniqueWithoutUserInput | WorkoutPlanUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: WorkoutPlanCreateManyUserInputEnvelope
    set?: WorkoutPlanWhereUniqueInput | WorkoutPlanWhereUniqueInput[]
    disconnect?: WorkoutPlanWhereUniqueInput | WorkoutPlanWhereUniqueInput[]
    delete?: WorkoutPlanWhereUniqueInput | WorkoutPlanWhereUniqueInput[]
    connect?: WorkoutPlanWhereUniqueInput | WorkoutPlanWhereUniqueInput[]
    update?: WorkoutPlanUpdateWithWhereUniqueWithoutUserInput | WorkoutPlanUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: WorkoutPlanUpdateManyWithWhereWithoutUserInput | WorkoutPlanUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: WorkoutPlanScalarWhereInput | WorkoutPlanScalarWhereInput[]
  }

  export type ProgressEntryUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<ProgressEntryCreateWithoutUserInput, ProgressEntryUncheckedCreateWithoutUserInput> | ProgressEntryCreateWithoutUserInput[] | ProgressEntryUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ProgressEntryCreateOrConnectWithoutUserInput | ProgressEntryCreateOrConnectWithoutUserInput[]
    upsert?: ProgressEntryUpsertWithWhereUniqueWithoutUserInput | ProgressEntryUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: ProgressEntryCreateManyUserInputEnvelope
    set?: ProgressEntryWhereUniqueInput | ProgressEntryWhereUniqueInput[]
    disconnect?: ProgressEntryWhereUniqueInput | ProgressEntryWhereUniqueInput[]
    delete?: ProgressEntryWhereUniqueInput | ProgressEntryWhereUniqueInput[]
    connect?: ProgressEntryWhereUniqueInput | ProgressEntryWhereUniqueInput[]
    update?: ProgressEntryUpdateWithWhereUniqueWithoutUserInput | ProgressEntryUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: ProgressEntryUpdateManyWithWhereWithoutUserInput | ProgressEntryUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: ProgressEntryScalarWhereInput | ProgressEntryScalarWhereInput[]
  }

  export type PlanWorkoutCreateNestedManyWithoutWorkoutInput = {
    create?: XOR<PlanWorkoutCreateWithoutWorkoutInput, PlanWorkoutUncheckedCreateWithoutWorkoutInput> | PlanWorkoutCreateWithoutWorkoutInput[] | PlanWorkoutUncheckedCreateWithoutWorkoutInput[]
    connectOrCreate?: PlanWorkoutCreateOrConnectWithoutWorkoutInput | PlanWorkoutCreateOrConnectWithoutWorkoutInput[]
    createMany?: PlanWorkoutCreateManyWorkoutInputEnvelope
    connect?: PlanWorkoutWhereUniqueInput | PlanWorkoutWhereUniqueInput[]
  }

  export type ProgressEntryCreateNestedManyWithoutWorkoutInput = {
    create?: XOR<ProgressEntryCreateWithoutWorkoutInput, ProgressEntryUncheckedCreateWithoutWorkoutInput> | ProgressEntryCreateWithoutWorkoutInput[] | ProgressEntryUncheckedCreateWithoutWorkoutInput[]
    connectOrCreate?: ProgressEntryCreateOrConnectWithoutWorkoutInput | ProgressEntryCreateOrConnectWithoutWorkoutInput[]
    createMany?: ProgressEntryCreateManyWorkoutInputEnvelope
    connect?: ProgressEntryWhereUniqueInput | ProgressEntryWhereUniqueInput[]
  }

  export type PlanWorkoutUncheckedCreateNestedManyWithoutWorkoutInput = {
    create?: XOR<PlanWorkoutCreateWithoutWorkoutInput, PlanWorkoutUncheckedCreateWithoutWorkoutInput> | PlanWorkoutCreateWithoutWorkoutInput[] | PlanWorkoutUncheckedCreateWithoutWorkoutInput[]
    connectOrCreate?: PlanWorkoutCreateOrConnectWithoutWorkoutInput | PlanWorkoutCreateOrConnectWithoutWorkoutInput[]
    createMany?: PlanWorkoutCreateManyWorkoutInputEnvelope
    connect?: PlanWorkoutWhereUniqueInput | PlanWorkoutWhereUniqueInput[]
  }

  export type ProgressEntryUncheckedCreateNestedManyWithoutWorkoutInput = {
    create?: XOR<ProgressEntryCreateWithoutWorkoutInput, ProgressEntryUncheckedCreateWithoutWorkoutInput> | ProgressEntryCreateWithoutWorkoutInput[] | ProgressEntryUncheckedCreateWithoutWorkoutInput[]
    connectOrCreate?: ProgressEntryCreateOrConnectWithoutWorkoutInput | ProgressEntryCreateOrConnectWithoutWorkoutInput[]
    createMany?: ProgressEntryCreateManyWorkoutInputEnvelope
    connect?: ProgressEntryWhereUniqueInput | ProgressEntryWhereUniqueInput[]
  }

  export type PlanWorkoutUpdateManyWithoutWorkoutNestedInput = {
    create?: XOR<PlanWorkoutCreateWithoutWorkoutInput, PlanWorkoutUncheckedCreateWithoutWorkoutInput> | PlanWorkoutCreateWithoutWorkoutInput[] | PlanWorkoutUncheckedCreateWithoutWorkoutInput[]
    connectOrCreate?: PlanWorkoutCreateOrConnectWithoutWorkoutInput | PlanWorkoutCreateOrConnectWithoutWorkoutInput[]
    upsert?: PlanWorkoutUpsertWithWhereUniqueWithoutWorkoutInput | PlanWorkoutUpsertWithWhereUniqueWithoutWorkoutInput[]
    createMany?: PlanWorkoutCreateManyWorkoutInputEnvelope
    set?: PlanWorkoutWhereUniqueInput | PlanWorkoutWhereUniqueInput[]
    disconnect?: PlanWorkoutWhereUniqueInput | PlanWorkoutWhereUniqueInput[]
    delete?: PlanWorkoutWhereUniqueInput | PlanWorkoutWhereUniqueInput[]
    connect?: PlanWorkoutWhereUniqueInput | PlanWorkoutWhereUniqueInput[]
    update?: PlanWorkoutUpdateWithWhereUniqueWithoutWorkoutInput | PlanWorkoutUpdateWithWhereUniqueWithoutWorkoutInput[]
    updateMany?: PlanWorkoutUpdateManyWithWhereWithoutWorkoutInput | PlanWorkoutUpdateManyWithWhereWithoutWorkoutInput[]
    deleteMany?: PlanWorkoutScalarWhereInput | PlanWorkoutScalarWhereInput[]
  }

  export type ProgressEntryUpdateManyWithoutWorkoutNestedInput = {
    create?: XOR<ProgressEntryCreateWithoutWorkoutInput, ProgressEntryUncheckedCreateWithoutWorkoutInput> | ProgressEntryCreateWithoutWorkoutInput[] | ProgressEntryUncheckedCreateWithoutWorkoutInput[]
    connectOrCreate?: ProgressEntryCreateOrConnectWithoutWorkoutInput | ProgressEntryCreateOrConnectWithoutWorkoutInput[]
    upsert?: ProgressEntryUpsertWithWhereUniqueWithoutWorkoutInput | ProgressEntryUpsertWithWhereUniqueWithoutWorkoutInput[]
    createMany?: ProgressEntryCreateManyWorkoutInputEnvelope
    set?: ProgressEntryWhereUniqueInput | ProgressEntryWhereUniqueInput[]
    disconnect?: ProgressEntryWhereUniqueInput | ProgressEntryWhereUniqueInput[]
    delete?: ProgressEntryWhereUniqueInput | ProgressEntryWhereUniqueInput[]
    connect?: ProgressEntryWhereUniqueInput | ProgressEntryWhereUniqueInput[]
    update?: ProgressEntryUpdateWithWhereUniqueWithoutWorkoutInput | ProgressEntryUpdateWithWhereUniqueWithoutWorkoutInput[]
    updateMany?: ProgressEntryUpdateManyWithWhereWithoutWorkoutInput | ProgressEntryUpdateManyWithWhereWithoutWorkoutInput[]
    deleteMany?: ProgressEntryScalarWhereInput | ProgressEntryScalarWhereInput[]
  }

  export type PlanWorkoutUncheckedUpdateManyWithoutWorkoutNestedInput = {
    create?: XOR<PlanWorkoutCreateWithoutWorkoutInput, PlanWorkoutUncheckedCreateWithoutWorkoutInput> | PlanWorkoutCreateWithoutWorkoutInput[] | PlanWorkoutUncheckedCreateWithoutWorkoutInput[]
    connectOrCreate?: PlanWorkoutCreateOrConnectWithoutWorkoutInput | PlanWorkoutCreateOrConnectWithoutWorkoutInput[]
    upsert?: PlanWorkoutUpsertWithWhereUniqueWithoutWorkoutInput | PlanWorkoutUpsertWithWhereUniqueWithoutWorkoutInput[]
    createMany?: PlanWorkoutCreateManyWorkoutInputEnvelope
    set?: PlanWorkoutWhereUniqueInput | PlanWorkoutWhereUniqueInput[]
    disconnect?: PlanWorkoutWhereUniqueInput | PlanWorkoutWhereUniqueInput[]
    delete?: PlanWorkoutWhereUniqueInput | PlanWorkoutWhereUniqueInput[]
    connect?: PlanWorkoutWhereUniqueInput | PlanWorkoutWhereUniqueInput[]
    update?: PlanWorkoutUpdateWithWhereUniqueWithoutWorkoutInput | PlanWorkoutUpdateWithWhereUniqueWithoutWorkoutInput[]
    updateMany?: PlanWorkoutUpdateManyWithWhereWithoutWorkoutInput | PlanWorkoutUpdateManyWithWhereWithoutWorkoutInput[]
    deleteMany?: PlanWorkoutScalarWhereInput | PlanWorkoutScalarWhereInput[]
  }

  export type ProgressEntryUncheckedUpdateManyWithoutWorkoutNestedInput = {
    create?: XOR<ProgressEntryCreateWithoutWorkoutInput, ProgressEntryUncheckedCreateWithoutWorkoutInput> | ProgressEntryCreateWithoutWorkoutInput[] | ProgressEntryUncheckedCreateWithoutWorkoutInput[]
    connectOrCreate?: ProgressEntryCreateOrConnectWithoutWorkoutInput | ProgressEntryCreateOrConnectWithoutWorkoutInput[]
    upsert?: ProgressEntryUpsertWithWhereUniqueWithoutWorkoutInput | ProgressEntryUpsertWithWhereUniqueWithoutWorkoutInput[]
    createMany?: ProgressEntryCreateManyWorkoutInputEnvelope
    set?: ProgressEntryWhereUniqueInput | ProgressEntryWhereUniqueInput[]
    disconnect?: ProgressEntryWhereUniqueInput | ProgressEntryWhereUniqueInput[]
    delete?: ProgressEntryWhereUniqueInput | ProgressEntryWhereUniqueInput[]
    connect?: ProgressEntryWhereUniqueInput | ProgressEntryWhereUniqueInput[]
    update?: ProgressEntryUpdateWithWhereUniqueWithoutWorkoutInput | ProgressEntryUpdateWithWhereUniqueWithoutWorkoutInput[]
    updateMany?: ProgressEntryUpdateManyWithWhereWithoutWorkoutInput | ProgressEntryUpdateManyWithWhereWithoutWorkoutInput[]
    deleteMany?: ProgressEntryScalarWhereInput | ProgressEntryScalarWhereInput[]
  }

  export type UserCreateNestedOneWithoutWorkoutPlansInput = {
    create?: XOR<UserCreateWithoutWorkoutPlansInput, UserUncheckedCreateWithoutWorkoutPlansInput>
    connectOrCreate?: UserCreateOrConnectWithoutWorkoutPlansInput
    connect?: UserWhereUniqueInput
  }

  export type PlanWorkoutCreateNestedManyWithoutPlanInput = {
    create?: XOR<PlanWorkoutCreateWithoutPlanInput, PlanWorkoutUncheckedCreateWithoutPlanInput> | PlanWorkoutCreateWithoutPlanInput[] | PlanWorkoutUncheckedCreateWithoutPlanInput[]
    connectOrCreate?: PlanWorkoutCreateOrConnectWithoutPlanInput | PlanWorkoutCreateOrConnectWithoutPlanInput[]
    createMany?: PlanWorkoutCreateManyPlanInputEnvelope
    connect?: PlanWorkoutWhereUniqueInput | PlanWorkoutWhereUniqueInput[]
  }

  export type PlanWorkoutUncheckedCreateNestedManyWithoutPlanInput = {
    create?: XOR<PlanWorkoutCreateWithoutPlanInput, PlanWorkoutUncheckedCreateWithoutPlanInput> | PlanWorkoutCreateWithoutPlanInput[] | PlanWorkoutUncheckedCreateWithoutPlanInput[]
    connectOrCreate?: PlanWorkoutCreateOrConnectWithoutPlanInput | PlanWorkoutCreateOrConnectWithoutPlanInput[]
    createMany?: PlanWorkoutCreateManyPlanInputEnvelope
    connect?: PlanWorkoutWhereUniqueInput | PlanWorkoutWhereUniqueInput[]
  }

  export type UserUpdateOneRequiredWithoutWorkoutPlansNestedInput = {
    create?: XOR<UserCreateWithoutWorkoutPlansInput, UserUncheckedCreateWithoutWorkoutPlansInput>
    connectOrCreate?: UserCreateOrConnectWithoutWorkoutPlansInput
    upsert?: UserUpsertWithoutWorkoutPlansInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutWorkoutPlansInput, UserUpdateWithoutWorkoutPlansInput>, UserUncheckedUpdateWithoutWorkoutPlansInput>
  }

  export type PlanWorkoutUpdateManyWithoutPlanNestedInput = {
    create?: XOR<PlanWorkoutCreateWithoutPlanInput, PlanWorkoutUncheckedCreateWithoutPlanInput> | PlanWorkoutCreateWithoutPlanInput[] | PlanWorkoutUncheckedCreateWithoutPlanInput[]
    connectOrCreate?: PlanWorkoutCreateOrConnectWithoutPlanInput | PlanWorkoutCreateOrConnectWithoutPlanInput[]
    upsert?: PlanWorkoutUpsertWithWhereUniqueWithoutPlanInput | PlanWorkoutUpsertWithWhereUniqueWithoutPlanInput[]
    createMany?: PlanWorkoutCreateManyPlanInputEnvelope
    set?: PlanWorkoutWhereUniqueInput | PlanWorkoutWhereUniqueInput[]
    disconnect?: PlanWorkoutWhereUniqueInput | PlanWorkoutWhereUniqueInput[]
    delete?: PlanWorkoutWhereUniqueInput | PlanWorkoutWhereUniqueInput[]
    connect?: PlanWorkoutWhereUniqueInput | PlanWorkoutWhereUniqueInput[]
    update?: PlanWorkoutUpdateWithWhereUniqueWithoutPlanInput | PlanWorkoutUpdateWithWhereUniqueWithoutPlanInput[]
    updateMany?: PlanWorkoutUpdateManyWithWhereWithoutPlanInput | PlanWorkoutUpdateManyWithWhereWithoutPlanInput[]
    deleteMany?: PlanWorkoutScalarWhereInput | PlanWorkoutScalarWhereInput[]
  }

  export type PlanWorkoutUncheckedUpdateManyWithoutPlanNestedInput = {
    create?: XOR<PlanWorkoutCreateWithoutPlanInput, PlanWorkoutUncheckedCreateWithoutPlanInput> | PlanWorkoutCreateWithoutPlanInput[] | PlanWorkoutUncheckedCreateWithoutPlanInput[]
    connectOrCreate?: PlanWorkoutCreateOrConnectWithoutPlanInput | PlanWorkoutCreateOrConnectWithoutPlanInput[]
    upsert?: PlanWorkoutUpsertWithWhereUniqueWithoutPlanInput | PlanWorkoutUpsertWithWhereUniqueWithoutPlanInput[]
    createMany?: PlanWorkoutCreateManyPlanInputEnvelope
    set?: PlanWorkoutWhereUniqueInput | PlanWorkoutWhereUniqueInput[]
    disconnect?: PlanWorkoutWhereUniqueInput | PlanWorkoutWhereUniqueInput[]
    delete?: PlanWorkoutWhereUniqueInput | PlanWorkoutWhereUniqueInput[]
    connect?: PlanWorkoutWhereUniqueInput | PlanWorkoutWhereUniqueInput[]
    update?: PlanWorkoutUpdateWithWhereUniqueWithoutPlanInput | PlanWorkoutUpdateWithWhereUniqueWithoutPlanInput[]
    updateMany?: PlanWorkoutUpdateManyWithWhereWithoutPlanInput | PlanWorkoutUpdateManyWithWhereWithoutPlanInput[]
    deleteMany?: PlanWorkoutScalarWhereInput | PlanWorkoutScalarWhereInput[]
  }

  export type WorkoutPlanCreateNestedOneWithoutPlanWorkoutsInput = {
    create?: XOR<WorkoutPlanCreateWithoutPlanWorkoutsInput, WorkoutPlanUncheckedCreateWithoutPlanWorkoutsInput>
    connectOrCreate?: WorkoutPlanCreateOrConnectWithoutPlanWorkoutsInput
    connect?: WorkoutPlanWhereUniqueInput
  }

  export type WorkoutCreateNestedOneWithoutPlanWorkoutsInput = {
    create?: XOR<WorkoutCreateWithoutPlanWorkoutsInput, WorkoutUncheckedCreateWithoutPlanWorkoutsInput>
    connectOrCreate?: WorkoutCreateOrConnectWithoutPlanWorkoutsInput
    connect?: WorkoutWhereUniqueInput
  }

  export type WorkoutPlanUpdateOneRequiredWithoutPlanWorkoutsNestedInput = {
    create?: XOR<WorkoutPlanCreateWithoutPlanWorkoutsInput, WorkoutPlanUncheckedCreateWithoutPlanWorkoutsInput>
    connectOrCreate?: WorkoutPlanCreateOrConnectWithoutPlanWorkoutsInput
    upsert?: WorkoutPlanUpsertWithoutPlanWorkoutsInput
    connect?: WorkoutPlanWhereUniqueInput
    update?: XOR<XOR<WorkoutPlanUpdateToOneWithWhereWithoutPlanWorkoutsInput, WorkoutPlanUpdateWithoutPlanWorkoutsInput>, WorkoutPlanUncheckedUpdateWithoutPlanWorkoutsInput>
  }

  export type WorkoutUpdateOneRequiredWithoutPlanWorkoutsNestedInput = {
    create?: XOR<WorkoutCreateWithoutPlanWorkoutsInput, WorkoutUncheckedCreateWithoutPlanWorkoutsInput>
    connectOrCreate?: WorkoutCreateOrConnectWithoutPlanWorkoutsInput
    upsert?: WorkoutUpsertWithoutPlanWorkoutsInput
    connect?: WorkoutWhereUniqueInput
    update?: XOR<XOR<WorkoutUpdateToOneWithWhereWithoutPlanWorkoutsInput, WorkoutUpdateWithoutPlanWorkoutsInput>, WorkoutUncheckedUpdateWithoutPlanWorkoutsInput>
  }

  export type UserCreateNestedOneWithoutProgressEntriesInput = {
    create?: XOR<UserCreateWithoutProgressEntriesInput, UserUncheckedCreateWithoutProgressEntriesInput>
    connectOrCreate?: UserCreateOrConnectWithoutProgressEntriesInput
    connect?: UserWhereUniqueInput
  }

  export type WorkoutCreateNestedOneWithoutProgressEntriesInput = {
    create?: XOR<WorkoutCreateWithoutProgressEntriesInput, WorkoutUncheckedCreateWithoutProgressEntriesInput>
    connectOrCreate?: WorkoutCreateOrConnectWithoutProgressEntriesInput
    connect?: WorkoutWhereUniqueInput
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type UserUpdateOneRequiredWithoutProgressEntriesNestedInput = {
    create?: XOR<UserCreateWithoutProgressEntriesInput, UserUncheckedCreateWithoutProgressEntriesInput>
    connectOrCreate?: UserCreateOrConnectWithoutProgressEntriesInput
    upsert?: UserUpsertWithoutProgressEntriesInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutProgressEntriesInput, UserUpdateWithoutProgressEntriesInput>, UserUncheckedUpdateWithoutProgressEntriesInput>
  }

  export type WorkoutUpdateOneRequiredWithoutProgressEntriesNestedInput = {
    create?: XOR<WorkoutCreateWithoutProgressEntriesInput, WorkoutUncheckedCreateWithoutProgressEntriesInput>
    connectOrCreate?: WorkoutCreateOrConnectWithoutProgressEntriesInput
    upsert?: WorkoutUpsertWithoutProgressEntriesInput
    connect?: WorkoutWhereUniqueInput
    update?: XOR<XOR<WorkoutUpdateToOneWithWhereWithoutProgressEntriesInput, WorkoutUpdateWithoutProgressEntriesInput>, WorkoutUncheckedUpdateWithoutProgressEntriesInput>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedEnumRoleFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    notIn?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    not?: NestedEnumRoleFilter<$PrismaModel> | $Enums.Role
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedEnumRoleWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    notIn?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    not?: NestedEnumRoleWithAggregatesFilter<$PrismaModel> | $Enums.Role
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumRoleFilter<$PrismaModel>
    _max?: NestedEnumRoleFilter<$PrismaModel>
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type WorkoutPlanCreateWithoutUserInput = {
    title: string
    goal: string
    duration_weeks: number
    createdAt?: Date | string
    updatedAt?: Date | string
    planWorkouts?: PlanWorkoutCreateNestedManyWithoutPlanInput
  }

  export type WorkoutPlanUncheckedCreateWithoutUserInput = {
    id?: number
    title: string
    goal: string
    duration_weeks: number
    createdAt?: Date | string
    updatedAt?: Date | string
    planWorkouts?: PlanWorkoutUncheckedCreateNestedManyWithoutPlanInput
  }

  export type WorkoutPlanCreateOrConnectWithoutUserInput = {
    where: WorkoutPlanWhereUniqueInput
    create: XOR<WorkoutPlanCreateWithoutUserInput, WorkoutPlanUncheckedCreateWithoutUserInput>
  }

  export type WorkoutPlanCreateManyUserInputEnvelope = {
    data: WorkoutPlanCreateManyUserInput | WorkoutPlanCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type ProgressEntryCreateWithoutUserInput = {
    date_completed: Date | string
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    workout: WorkoutCreateNestedOneWithoutProgressEntriesInput
  }

  export type ProgressEntryUncheckedCreateWithoutUserInput = {
    id?: number
    workout_id: number
    date_completed: Date | string
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type ProgressEntryCreateOrConnectWithoutUserInput = {
    where: ProgressEntryWhereUniqueInput
    create: XOR<ProgressEntryCreateWithoutUserInput, ProgressEntryUncheckedCreateWithoutUserInput>
  }

  export type ProgressEntryCreateManyUserInputEnvelope = {
    data: ProgressEntryCreateManyUserInput | ProgressEntryCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type WorkoutPlanUpsertWithWhereUniqueWithoutUserInput = {
    where: WorkoutPlanWhereUniqueInput
    update: XOR<WorkoutPlanUpdateWithoutUserInput, WorkoutPlanUncheckedUpdateWithoutUserInput>
    create: XOR<WorkoutPlanCreateWithoutUserInput, WorkoutPlanUncheckedCreateWithoutUserInput>
  }

  export type WorkoutPlanUpdateWithWhereUniqueWithoutUserInput = {
    where: WorkoutPlanWhereUniqueInput
    data: XOR<WorkoutPlanUpdateWithoutUserInput, WorkoutPlanUncheckedUpdateWithoutUserInput>
  }

  export type WorkoutPlanUpdateManyWithWhereWithoutUserInput = {
    where: WorkoutPlanScalarWhereInput
    data: XOR<WorkoutPlanUpdateManyMutationInput, WorkoutPlanUncheckedUpdateManyWithoutUserInput>
  }

  export type WorkoutPlanScalarWhereInput = {
    AND?: WorkoutPlanScalarWhereInput | WorkoutPlanScalarWhereInput[]
    OR?: WorkoutPlanScalarWhereInput[]
    NOT?: WorkoutPlanScalarWhereInput | WorkoutPlanScalarWhereInput[]
    id?: IntFilter<"WorkoutPlan"> | number
    user_id?: IntFilter<"WorkoutPlan"> | number
    title?: StringFilter<"WorkoutPlan"> | string
    goal?: StringFilter<"WorkoutPlan"> | string
    duration_weeks?: IntFilter<"WorkoutPlan"> | number
    createdAt?: DateTimeFilter<"WorkoutPlan"> | Date | string
    updatedAt?: DateTimeFilter<"WorkoutPlan"> | Date | string
  }

  export type ProgressEntryUpsertWithWhereUniqueWithoutUserInput = {
    where: ProgressEntryWhereUniqueInput
    update: XOR<ProgressEntryUpdateWithoutUserInput, ProgressEntryUncheckedUpdateWithoutUserInput>
    create: XOR<ProgressEntryCreateWithoutUserInput, ProgressEntryUncheckedCreateWithoutUserInput>
  }

  export type ProgressEntryUpdateWithWhereUniqueWithoutUserInput = {
    where: ProgressEntryWhereUniqueInput
    data: XOR<ProgressEntryUpdateWithoutUserInput, ProgressEntryUncheckedUpdateWithoutUserInput>
  }

  export type ProgressEntryUpdateManyWithWhereWithoutUserInput = {
    where: ProgressEntryScalarWhereInput
    data: XOR<ProgressEntryUpdateManyMutationInput, ProgressEntryUncheckedUpdateManyWithoutUserInput>
  }

  export type ProgressEntryScalarWhereInput = {
    AND?: ProgressEntryScalarWhereInput | ProgressEntryScalarWhereInput[]
    OR?: ProgressEntryScalarWhereInput[]
    NOT?: ProgressEntryScalarWhereInput | ProgressEntryScalarWhereInput[]
    id?: IntFilter<"ProgressEntry"> | number
    user_id?: IntFilter<"ProgressEntry"> | number
    workout_id?: IntFilter<"ProgressEntry"> | number
    date_completed?: DateTimeFilter<"ProgressEntry"> | Date | string
    notes?: StringNullableFilter<"ProgressEntry"> | string | null
    createdAt?: DateTimeFilter<"ProgressEntry"> | Date | string
    updatedAt?: DateTimeFilter<"ProgressEntry"> | Date | string
  }

  export type PlanWorkoutCreateWithoutWorkoutInput = {
    day_number: number
    plan: WorkoutPlanCreateNestedOneWithoutPlanWorkoutsInput
  }

  export type PlanWorkoutUncheckedCreateWithoutWorkoutInput = {
    plan_id: number
    day_number: number
  }

  export type PlanWorkoutCreateOrConnectWithoutWorkoutInput = {
    where: PlanWorkoutWhereUniqueInput
    create: XOR<PlanWorkoutCreateWithoutWorkoutInput, PlanWorkoutUncheckedCreateWithoutWorkoutInput>
  }

  export type PlanWorkoutCreateManyWorkoutInputEnvelope = {
    data: PlanWorkoutCreateManyWorkoutInput | PlanWorkoutCreateManyWorkoutInput[]
    skipDuplicates?: boolean
  }

  export type ProgressEntryCreateWithoutWorkoutInput = {
    date_completed: Date | string
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    user: UserCreateNestedOneWithoutProgressEntriesInput
  }

  export type ProgressEntryUncheckedCreateWithoutWorkoutInput = {
    id?: number
    user_id: number
    date_completed: Date | string
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type ProgressEntryCreateOrConnectWithoutWorkoutInput = {
    where: ProgressEntryWhereUniqueInput
    create: XOR<ProgressEntryCreateWithoutWorkoutInput, ProgressEntryUncheckedCreateWithoutWorkoutInput>
  }

  export type ProgressEntryCreateManyWorkoutInputEnvelope = {
    data: ProgressEntryCreateManyWorkoutInput | ProgressEntryCreateManyWorkoutInput[]
    skipDuplicates?: boolean
  }

  export type PlanWorkoutUpsertWithWhereUniqueWithoutWorkoutInput = {
    where: PlanWorkoutWhereUniqueInput
    update: XOR<PlanWorkoutUpdateWithoutWorkoutInput, PlanWorkoutUncheckedUpdateWithoutWorkoutInput>
    create: XOR<PlanWorkoutCreateWithoutWorkoutInput, PlanWorkoutUncheckedCreateWithoutWorkoutInput>
  }

  export type PlanWorkoutUpdateWithWhereUniqueWithoutWorkoutInput = {
    where: PlanWorkoutWhereUniqueInput
    data: XOR<PlanWorkoutUpdateWithoutWorkoutInput, PlanWorkoutUncheckedUpdateWithoutWorkoutInput>
  }

  export type PlanWorkoutUpdateManyWithWhereWithoutWorkoutInput = {
    where: PlanWorkoutScalarWhereInput
    data: XOR<PlanWorkoutUpdateManyMutationInput, PlanWorkoutUncheckedUpdateManyWithoutWorkoutInput>
  }

  export type PlanWorkoutScalarWhereInput = {
    AND?: PlanWorkoutScalarWhereInput | PlanWorkoutScalarWhereInput[]
    OR?: PlanWorkoutScalarWhereInput[]
    NOT?: PlanWorkoutScalarWhereInput | PlanWorkoutScalarWhereInput[]
    plan_id?: IntFilter<"PlanWorkout"> | number
    workout_id?: IntFilter<"PlanWorkout"> | number
    day_number?: IntFilter<"PlanWorkout"> | number
  }

  export type ProgressEntryUpsertWithWhereUniqueWithoutWorkoutInput = {
    where: ProgressEntryWhereUniqueInput
    update: XOR<ProgressEntryUpdateWithoutWorkoutInput, ProgressEntryUncheckedUpdateWithoutWorkoutInput>
    create: XOR<ProgressEntryCreateWithoutWorkoutInput, ProgressEntryUncheckedCreateWithoutWorkoutInput>
  }

  export type ProgressEntryUpdateWithWhereUniqueWithoutWorkoutInput = {
    where: ProgressEntryWhereUniqueInput
    data: XOR<ProgressEntryUpdateWithoutWorkoutInput, ProgressEntryUncheckedUpdateWithoutWorkoutInput>
  }

  export type ProgressEntryUpdateManyWithWhereWithoutWorkoutInput = {
    where: ProgressEntryScalarWhereInput
    data: XOR<ProgressEntryUpdateManyMutationInput, ProgressEntryUncheckedUpdateManyWithoutWorkoutInput>
  }

  export type UserCreateWithoutWorkoutPlansInput = {
    name: string
    email: string
    password_hash: string
    role?: $Enums.Role
    createdAt?: Date | string
    updatedAt?: Date | string
    progressEntries?: ProgressEntryCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutWorkoutPlansInput = {
    id?: number
    name: string
    email: string
    password_hash: string
    role?: $Enums.Role
    createdAt?: Date | string
    updatedAt?: Date | string
    progressEntries?: ProgressEntryUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutWorkoutPlansInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutWorkoutPlansInput, UserUncheckedCreateWithoutWorkoutPlansInput>
  }

  export type PlanWorkoutCreateWithoutPlanInput = {
    day_number: number
    workout: WorkoutCreateNestedOneWithoutPlanWorkoutsInput
  }

  export type PlanWorkoutUncheckedCreateWithoutPlanInput = {
    workout_id: number
    day_number: number
  }

  export type PlanWorkoutCreateOrConnectWithoutPlanInput = {
    where: PlanWorkoutWhereUniqueInput
    create: XOR<PlanWorkoutCreateWithoutPlanInput, PlanWorkoutUncheckedCreateWithoutPlanInput>
  }

  export type PlanWorkoutCreateManyPlanInputEnvelope = {
    data: PlanWorkoutCreateManyPlanInput | PlanWorkoutCreateManyPlanInput[]
    skipDuplicates?: boolean
  }

  export type UserUpsertWithoutWorkoutPlansInput = {
    update: XOR<UserUpdateWithoutWorkoutPlansInput, UserUncheckedUpdateWithoutWorkoutPlansInput>
    create: XOR<UserCreateWithoutWorkoutPlansInput, UserUncheckedCreateWithoutWorkoutPlansInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutWorkoutPlansInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutWorkoutPlansInput, UserUncheckedUpdateWithoutWorkoutPlansInput>
  }

  export type UserUpdateWithoutWorkoutPlansInput = {
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    progressEntries?: ProgressEntryUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutWorkoutPlansInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    progressEntries?: ProgressEntryUncheckedUpdateManyWithoutUserNestedInput
  }

  export type PlanWorkoutUpsertWithWhereUniqueWithoutPlanInput = {
    where: PlanWorkoutWhereUniqueInput
    update: XOR<PlanWorkoutUpdateWithoutPlanInput, PlanWorkoutUncheckedUpdateWithoutPlanInput>
    create: XOR<PlanWorkoutCreateWithoutPlanInput, PlanWorkoutUncheckedCreateWithoutPlanInput>
  }

  export type PlanWorkoutUpdateWithWhereUniqueWithoutPlanInput = {
    where: PlanWorkoutWhereUniqueInput
    data: XOR<PlanWorkoutUpdateWithoutPlanInput, PlanWorkoutUncheckedUpdateWithoutPlanInput>
  }

  export type PlanWorkoutUpdateManyWithWhereWithoutPlanInput = {
    where: PlanWorkoutScalarWhereInput
    data: XOR<PlanWorkoutUpdateManyMutationInput, PlanWorkoutUncheckedUpdateManyWithoutPlanInput>
  }

  export type WorkoutPlanCreateWithoutPlanWorkoutsInput = {
    title: string
    goal: string
    duration_weeks: number
    createdAt?: Date | string
    updatedAt?: Date | string
    user: UserCreateNestedOneWithoutWorkoutPlansInput
  }

  export type WorkoutPlanUncheckedCreateWithoutPlanWorkoutsInput = {
    id?: number
    user_id: number
    title: string
    goal: string
    duration_weeks: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type WorkoutPlanCreateOrConnectWithoutPlanWorkoutsInput = {
    where: WorkoutPlanWhereUniqueInput
    create: XOR<WorkoutPlanCreateWithoutPlanWorkoutsInput, WorkoutPlanUncheckedCreateWithoutPlanWorkoutsInput>
  }

  export type WorkoutCreateWithoutPlanWorkoutsInput = {
    title: string
    description: string
    category: string
    difficulty: string
    duration_minutes: number
    createdAt?: Date | string
    updatedAt?: Date | string
    progressEntries?: ProgressEntryCreateNestedManyWithoutWorkoutInput
  }

  export type WorkoutUncheckedCreateWithoutPlanWorkoutsInput = {
    id?: number
    title: string
    description: string
    category: string
    difficulty: string
    duration_minutes: number
    createdAt?: Date | string
    updatedAt?: Date | string
    progressEntries?: ProgressEntryUncheckedCreateNestedManyWithoutWorkoutInput
  }

  export type WorkoutCreateOrConnectWithoutPlanWorkoutsInput = {
    where: WorkoutWhereUniqueInput
    create: XOR<WorkoutCreateWithoutPlanWorkoutsInput, WorkoutUncheckedCreateWithoutPlanWorkoutsInput>
  }

  export type WorkoutPlanUpsertWithoutPlanWorkoutsInput = {
    update: XOR<WorkoutPlanUpdateWithoutPlanWorkoutsInput, WorkoutPlanUncheckedUpdateWithoutPlanWorkoutsInput>
    create: XOR<WorkoutPlanCreateWithoutPlanWorkoutsInput, WorkoutPlanUncheckedCreateWithoutPlanWorkoutsInput>
    where?: WorkoutPlanWhereInput
  }

  export type WorkoutPlanUpdateToOneWithWhereWithoutPlanWorkoutsInput = {
    where?: WorkoutPlanWhereInput
    data: XOR<WorkoutPlanUpdateWithoutPlanWorkoutsInput, WorkoutPlanUncheckedUpdateWithoutPlanWorkoutsInput>
  }

  export type WorkoutPlanUpdateWithoutPlanWorkoutsInput = {
    title?: StringFieldUpdateOperationsInput | string
    goal?: StringFieldUpdateOperationsInput | string
    duration_weeks?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutWorkoutPlansNestedInput
  }

  export type WorkoutPlanUncheckedUpdateWithoutPlanWorkoutsInput = {
    id?: IntFieldUpdateOperationsInput | number
    user_id?: IntFieldUpdateOperationsInput | number
    title?: StringFieldUpdateOperationsInput | string
    goal?: StringFieldUpdateOperationsInput | string
    duration_weeks?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type WorkoutUpsertWithoutPlanWorkoutsInput = {
    update: XOR<WorkoutUpdateWithoutPlanWorkoutsInput, WorkoutUncheckedUpdateWithoutPlanWorkoutsInput>
    create: XOR<WorkoutCreateWithoutPlanWorkoutsInput, WorkoutUncheckedCreateWithoutPlanWorkoutsInput>
    where?: WorkoutWhereInput
  }

  export type WorkoutUpdateToOneWithWhereWithoutPlanWorkoutsInput = {
    where?: WorkoutWhereInput
    data: XOR<WorkoutUpdateWithoutPlanWorkoutsInput, WorkoutUncheckedUpdateWithoutPlanWorkoutsInput>
  }

  export type WorkoutUpdateWithoutPlanWorkoutsInput = {
    title?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    difficulty?: StringFieldUpdateOperationsInput | string
    duration_minutes?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    progressEntries?: ProgressEntryUpdateManyWithoutWorkoutNestedInput
  }

  export type WorkoutUncheckedUpdateWithoutPlanWorkoutsInput = {
    id?: IntFieldUpdateOperationsInput | number
    title?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    difficulty?: StringFieldUpdateOperationsInput | string
    duration_minutes?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    progressEntries?: ProgressEntryUncheckedUpdateManyWithoutWorkoutNestedInput
  }

  export type UserCreateWithoutProgressEntriesInput = {
    name: string
    email: string
    password_hash: string
    role?: $Enums.Role
    createdAt?: Date | string
    updatedAt?: Date | string
    workoutPlans?: WorkoutPlanCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutProgressEntriesInput = {
    id?: number
    name: string
    email: string
    password_hash: string
    role?: $Enums.Role
    createdAt?: Date | string
    updatedAt?: Date | string
    workoutPlans?: WorkoutPlanUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutProgressEntriesInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutProgressEntriesInput, UserUncheckedCreateWithoutProgressEntriesInput>
  }

  export type WorkoutCreateWithoutProgressEntriesInput = {
    title: string
    description: string
    category: string
    difficulty: string
    duration_minutes: number
    createdAt?: Date | string
    updatedAt?: Date | string
    planWorkouts?: PlanWorkoutCreateNestedManyWithoutWorkoutInput
  }

  export type WorkoutUncheckedCreateWithoutProgressEntriesInput = {
    id?: number
    title: string
    description: string
    category: string
    difficulty: string
    duration_minutes: number
    createdAt?: Date | string
    updatedAt?: Date | string
    planWorkouts?: PlanWorkoutUncheckedCreateNestedManyWithoutWorkoutInput
  }

  export type WorkoutCreateOrConnectWithoutProgressEntriesInput = {
    where: WorkoutWhereUniqueInput
    create: XOR<WorkoutCreateWithoutProgressEntriesInput, WorkoutUncheckedCreateWithoutProgressEntriesInput>
  }

  export type UserUpsertWithoutProgressEntriesInput = {
    update: XOR<UserUpdateWithoutProgressEntriesInput, UserUncheckedUpdateWithoutProgressEntriesInput>
    create: XOR<UserCreateWithoutProgressEntriesInput, UserUncheckedCreateWithoutProgressEntriesInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutProgressEntriesInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutProgressEntriesInput, UserUncheckedUpdateWithoutProgressEntriesInput>
  }

  export type UserUpdateWithoutProgressEntriesInput = {
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    workoutPlans?: WorkoutPlanUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutProgressEntriesInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    workoutPlans?: WorkoutPlanUncheckedUpdateManyWithoutUserNestedInput
  }

  export type WorkoutUpsertWithoutProgressEntriesInput = {
    update: XOR<WorkoutUpdateWithoutProgressEntriesInput, WorkoutUncheckedUpdateWithoutProgressEntriesInput>
    create: XOR<WorkoutCreateWithoutProgressEntriesInput, WorkoutUncheckedCreateWithoutProgressEntriesInput>
    where?: WorkoutWhereInput
  }

  export type WorkoutUpdateToOneWithWhereWithoutProgressEntriesInput = {
    where?: WorkoutWhereInput
    data: XOR<WorkoutUpdateWithoutProgressEntriesInput, WorkoutUncheckedUpdateWithoutProgressEntriesInput>
  }

  export type WorkoutUpdateWithoutProgressEntriesInput = {
    title?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    difficulty?: StringFieldUpdateOperationsInput | string
    duration_minutes?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    planWorkouts?: PlanWorkoutUpdateManyWithoutWorkoutNestedInput
  }

  export type WorkoutUncheckedUpdateWithoutProgressEntriesInput = {
    id?: IntFieldUpdateOperationsInput | number
    title?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    difficulty?: StringFieldUpdateOperationsInput | string
    duration_minutes?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    planWorkouts?: PlanWorkoutUncheckedUpdateManyWithoutWorkoutNestedInput
  }

  export type WorkoutPlanCreateManyUserInput = {
    id?: number
    title: string
    goal: string
    duration_weeks: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type ProgressEntryCreateManyUserInput = {
    id?: number
    workout_id: number
    date_completed: Date | string
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type WorkoutPlanUpdateWithoutUserInput = {
    title?: StringFieldUpdateOperationsInput | string
    goal?: StringFieldUpdateOperationsInput | string
    duration_weeks?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    planWorkouts?: PlanWorkoutUpdateManyWithoutPlanNestedInput
  }

  export type WorkoutPlanUncheckedUpdateWithoutUserInput = {
    id?: IntFieldUpdateOperationsInput | number
    title?: StringFieldUpdateOperationsInput | string
    goal?: StringFieldUpdateOperationsInput | string
    duration_weeks?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    planWorkouts?: PlanWorkoutUncheckedUpdateManyWithoutPlanNestedInput
  }

  export type WorkoutPlanUncheckedUpdateManyWithoutUserInput = {
    id?: IntFieldUpdateOperationsInput | number
    title?: StringFieldUpdateOperationsInput | string
    goal?: StringFieldUpdateOperationsInput | string
    duration_weeks?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ProgressEntryUpdateWithoutUserInput = {
    date_completed?: DateTimeFieldUpdateOperationsInput | Date | string
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    workout?: WorkoutUpdateOneRequiredWithoutProgressEntriesNestedInput
  }

  export type ProgressEntryUncheckedUpdateWithoutUserInput = {
    id?: IntFieldUpdateOperationsInput | number
    workout_id?: IntFieldUpdateOperationsInput | number
    date_completed?: DateTimeFieldUpdateOperationsInput | Date | string
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ProgressEntryUncheckedUpdateManyWithoutUserInput = {
    id?: IntFieldUpdateOperationsInput | number
    workout_id?: IntFieldUpdateOperationsInput | number
    date_completed?: DateTimeFieldUpdateOperationsInput | Date | string
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PlanWorkoutCreateManyWorkoutInput = {
    plan_id: number
    day_number: number
  }

  export type ProgressEntryCreateManyWorkoutInput = {
    id?: number
    user_id: number
    date_completed: Date | string
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type PlanWorkoutUpdateWithoutWorkoutInput = {
    day_number?: IntFieldUpdateOperationsInput | number
    plan?: WorkoutPlanUpdateOneRequiredWithoutPlanWorkoutsNestedInput
  }

  export type PlanWorkoutUncheckedUpdateWithoutWorkoutInput = {
    plan_id?: IntFieldUpdateOperationsInput | number
    day_number?: IntFieldUpdateOperationsInput | number
  }

  export type PlanWorkoutUncheckedUpdateManyWithoutWorkoutInput = {
    plan_id?: IntFieldUpdateOperationsInput | number
    day_number?: IntFieldUpdateOperationsInput | number
  }

  export type ProgressEntryUpdateWithoutWorkoutInput = {
    date_completed?: DateTimeFieldUpdateOperationsInput | Date | string
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutProgressEntriesNestedInput
  }

  export type ProgressEntryUncheckedUpdateWithoutWorkoutInput = {
    id?: IntFieldUpdateOperationsInput | number
    user_id?: IntFieldUpdateOperationsInput | number
    date_completed?: DateTimeFieldUpdateOperationsInput | Date | string
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ProgressEntryUncheckedUpdateManyWithoutWorkoutInput = {
    id?: IntFieldUpdateOperationsInput | number
    user_id?: IntFieldUpdateOperationsInput | number
    date_completed?: DateTimeFieldUpdateOperationsInput | Date | string
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PlanWorkoutCreateManyPlanInput = {
    workout_id: number
    day_number: number
  }

  export type PlanWorkoutUpdateWithoutPlanInput = {
    day_number?: IntFieldUpdateOperationsInput | number
    workout?: WorkoutUpdateOneRequiredWithoutPlanWorkoutsNestedInput
  }

  export type PlanWorkoutUncheckedUpdateWithoutPlanInput = {
    workout_id?: IntFieldUpdateOperationsInput | number
    day_number?: IntFieldUpdateOperationsInput | number
  }

  export type PlanWorkoutUncheckedUpdateManyWithoutPlanInput = {
    workout_id?: IntFieldUpdateOperationsInput | number
    day_number?: IntFieldUpdateOperationsInput | number
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}